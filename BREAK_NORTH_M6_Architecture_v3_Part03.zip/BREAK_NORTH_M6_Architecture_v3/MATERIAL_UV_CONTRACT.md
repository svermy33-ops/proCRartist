# Material / UV contract

## Slots and independent surfaces

Wall: slot 0 FaceA (Blender -Y), 1 FaceB (+Y), 2 Interior (±X, ±Z).
Slab: slot 0 Top (+Z), 1 Bottom (-Z), 2 Interior (±X, ±Y).
Door/Hatch: slot 0 Frame, 1 Interior (opening-facing jamb/reveal faces).
WallEndCap: slot 0 Exterior, 1 Interior (-X mating face).
Column/Beam/Joints/Trims: slot 0 Structural.

각 에셋의 순서 및 family는 KitManifest.json의 materialNames / roles / families에 1:1로 기록합니다. FaceA와 FaceB는 같은 초기 family라도 서로 다른 Material 이름과 .mat를 사용합니다. Unity에서 한쪽을 PaintedMetalNeutral 계열의 재질로 교체해도 다른 면에 영향을 주지 않습니다. 색상 변형은 메시 복제가 아닌 Material tint 또는 게임의 MaterialPropertyBlock 정책으로 처리합니다. 서로 다른 roughness/metallic도 필요하면 별도 material을 사용하세요.

Surface는 비교적 밝고 미세한 기공, Interior는 더 어둡고 큰 골재를 사용합니다. ReinforcedInterior는 더 거친 골재이며 **실제 철근 geometry를 포함하지 않습니다**. 노출 철근이 필요한 파괴 상태는 게임 측 별도 구조/파편으로 처리합니다. 이 패키지는 유리·발광·투명 shader를 요구하지 않습니다.

## Texture maps

8 families: ConcreteSurfaceNeutral, ConcreteInterior, PaintedMetalNeutral, BareCutMetal, StructuralSteel, FloorNeutral, CeilingNeutral, ReinforcedInterior.

각 family는 seamless repeat용 1024² PNG 3개를 공유합니다.

| Suffix | 공간 | 사용 |
|---|---|---|
| BaseColor | sRGB | 중립색 albedo; material tint로 테마 색 지정 |
| Normal | linear / Unity NormalMap | OpenGL +Y tangent-space; 강도 기본 1.0 |
| MetallicSmoothness | linear | R=metallic, A=smoothness, G/B=0 |

Blender에서는 normal strength 1, MetallicSmoothness alpha를 1-alpha로 바꿔 roughness에 연결했습니다. Unity에서는 roughness 파일을 요구하지 않습니다. MS alpha를 투명도로 해석하지 마세요. Normal green을 임의로 반전하지 마세요. M6 v4/M7의 이전 normal strength를 이 패키지에 전역 적용하지 않습니다.

이 텍스처는 절차적으로 직접 제작한 재질이며 사진 스캔 재질이라고 주장하지 않습니다. 고주파 displacement를 실제 메시로 추가하지 않았습니다. 단면 normal은 조명 반응을 바꾸지만 단면의 실제 silhouette을 파괴 형태로 바꾸지는 않습니다.

## UV0 and runtime surface generation

Blender `UV0_Material` = Unity UV channel 0. `UV1_Lightmap` = Unity UV channel 1 (Mesh.uv2).
UV0는 atlas가 아닌 타일 좌표입니다. 전 family가 **2m / UV 1주기**입니다. Default material tiling (1,1), offset (0,0). 5m 벽에는 2.5주기, 2.5m 높이에는 1.25주기가 들어갑니다. 기둥/트림도 같은 물리 밀도를 사용합니다.

Blender local position (x,y,z), dominant face normal axis 및 부호 s 기준:

| 면 | U | V |
|---|---|---|
| ±X | s*y/2 | z/2 |
| ±Y | -s*x/2 | z/2 |
| ±Z | x/2 | s*y/2 |

곡면 bevel 면은 기하학적 face normal의 최대 절댓값 축을 사용합니다. 축이 바뀌는 곳에는 UV split이 있습니다. Mikk tangents를 재계산하세요. UV0를 [0,1] 안으로 임의 정규화하거나 세그먼트마다 다시 투영하면 물리 밀도/연속성이 달라집니다.

납품 모델/참고 장면은 모듈별 local UV입니다. 게임에서 긴 연속 표면을 생성할 때는 경계에 공통된 **boundary-space position**을 위 식에 넣고, 동일 boundary origin·rotation·UV phase를 모든 세그먼트와 Save/Load에 유지하세요. 이 패키지의 FBX를 transform scale로 늘리면 UV 물리 밀도도 늘어납니다. 길이가 다른 runtime segment는 vertex position에서 UV를 다시 계산하는 것이 기본입니다. World UV 적용 코드 자체는 본 패키지에 포함하지 않았습니다.

앞/뒷면 UV는 각각 right-handed tangent frame이므로 뒤쪽에서는 U가 반대입니다. 반대쪽 텍스처를 억지로 동일 좌표로 복사하지 마세요. Runtime 새 cut face는 Interior slot을 사용하고 위치/normal로 UV를 만든 뒤 normal/tangent를 갱신해야 합니다.

UV1은 별도 smart-project packing이며 양의 면적 island overlap은 검사했습니다. 작은 bevel face는 낮은 lightmap 해상도에서 subpixel이 될 수 있습니다. island padding과 실제 bake 품질은 프로젝트 lightmap 해상도에서 확인해야 합니다. Importer는 제공 UV1을 유지하며 자동 재생성을 끕니다.

FBX는 -Z Forward / Y Up, metre 단위를 사용합니다. Blender reimport에서 축 보정 rotation이 보일 수 있으므로 object.dimensions만이 아닌 world-space bounds/vertices로 비교했습니다. 실제 Unity 루트 scale과 bounds는 제공 검증 메뉴가 검사합니다.

## v2 기본 팔레트

중립 텍스처는 계속 공유하며 Blender multiply node / Unity material color에 동일한 sRGB 팔레트를 적용합니다. 아래 색은 최종 lit pixel 값이 아닌 tint 값입니다.

- ConcreteSurfaceNeutral: #E4D9C3
- ConcreteInterior: #C5BBA5
- PaintedMetalNeutral: #B5C8D8
- BareCutMetal: #CBD4DC
- StructuralSteel: #AABECE
- FloorNeutral: #C6C9C5
- CeilingNeutral: #EBE5D6
- ReinforcedInterior: #B8B3A5

금속 metallic/roughness와 base brightness는 Reports/Art_Revision_Metrics.json을 참고하세요. UV와 normal convention은 변경하지 않았습니다.
