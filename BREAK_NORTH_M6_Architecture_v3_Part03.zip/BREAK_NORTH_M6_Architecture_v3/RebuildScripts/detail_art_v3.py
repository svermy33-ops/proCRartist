import bpy,bmesh,pathlib,shutil,json,math,numpy as np
from mathutils import Vector
ROOT=pathlib.Path(__file__).resolve().parents[1];old=ROOT/'outputs/BREAK_NORTH_M6_Architecture_v2';out=ROOT/'outputs/BREAK_NORTH_M6_Architecture_v3'
shutil.copytree(old,out,dirs_exist_ok=True);assets=out/'Assets/BREAK_NORTH_M6_Architecture'
manifest=json.loads((assets/'KitManifest.json').read_text());manifest['version']='M6_Architecture_v3'
bpy.ops.wm.open_mainfile(filepath=str(out/'BlenderSources/BN_M6_Architecture_Library.blend'))
bpy.context.preferences.filepaths.save_version=0

def bolt(name,point,normal,r=.016,slot=0):
 n=Vector(normal);u=Vector((1,0,0)) if abs(n.x)<.9 else Vector((0,1,0));v=n.cross(u).normalized();u=v.cross(n).normalized();p=Vector(point)
 verts=[]
 # Head is seated 1mm into its support and has a small chamfer at the top.
 for depth,rad in [(-.001,r),(.005,r),(.008,r*.84)]:
  for i in range(6):
   a=i*math.tau/6;verts.append(tuple(p+n*depth+u*math.cos(a)*rad+v*math.sin(a)*rad))
 faces=[]
 for k in range(2):
  for i in range(6):faces.append((k*6+i,k*6+(i+1)%6,(k+1)*6+(i+1)%6,(k+1)*6+i))
 faces.extend([(0,3,2,1),(0,5,4,3),(12,13,14,15),(12,15,16,17)])
 return name,verts,faces,slot

def rim(name,poly,y0,y1,slot):
 verts=[(x,y,z) for y in [y0,y1] for x,z in poly]
 faces=[(0,3,2,1),(4,5,6,7)]+[(i,(i+1)%4,(i+1)%4+4,i+4) for i in range(4)]
 return name,verts,faces,slot

def append(ob,details):
 me=ob.data;verts=[tuple(v.co) for v in me.vertices];faces=[tuple(p.vertices) for p in me.polygons];slots=[p.material_index for p in me.polygons];count=len(me.polygons)
 olduv=[[[tuple(layer.data[l].uv) for l in p.loop_indices] for p in me.polygons] for layer in me.uv_layers]
 groups={g.name:[v.index for v in me.vertices if any(x.group==g.index for x in v.groups)] for g in ob.vertex_groups}
 mats=list(me.materials)
 for name,vs,fs,slot in details:
  start=len(verts);verts.extend(vs);faces.extend([tuple(start+i for i in f) for f in fs]);slots.extend([slot]*len(fs));groups[name]=list(range(start,len(verts)))
 new=bpy.data.meshes.new(me.name+'_DetailV3');new.from_pydata(verts,[],faces);new.update();ob.data=new
 for mat in mats:new.materials.append(mat)
 for p,s in zip(new.polygons,slots):p.material_index=s;p.use_smooth=True
 bm=bmesh.new();bm.from_mesh(new);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(new);bm.free()
 for g in list(ob.vertex_groups):ob.vertex_groups.remove(g)
 for name,indices in groups.items():ob.vertex_groups.new(name=name).add(indices,1,'REPLACE')
 for li,lname in enumerate(['UV0_Material','UV1_Lightmap']):
  layer=new.uv_layers.new(name=lname)
  for p in new.polygons:
   if p.index<count:
    for local,l in enumerate(p.loop_indices):layer.data[l].uv=olduv[li][p.index][local]
   else:
    a=max(range(3),key=lambda a:abs(p.normal[a]));s=1 if p.normal[a]>=0 else -1
    for l in p.loop_indices:
     c=new.vertices[new.loops[l].vertex_index].co
     u,v=(s*c.y,c.z) if a==0 else ((-s*c.x,c.z) if a==1 else (c.x,s*c.y))
     layer.data[l].uv=(u/2,v/2)
 bpy.ops.object.select_all(action='DESELECT');ob.hide_set(False);ob.select_set(True);bpy.context.view_layer.objects.active=ob
 new.uv_layers.active_index=1;bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=math.radians(66),island_margin=.035);bpy.ops.object.mode_set(mode='OBJECT')
 new.uv_layers.active_index=0;new.uv_layers[0].active_render=True
 mod=ob.modifiers.new('Weighted face normals V3','WEIGHTED_NORMAL');mod.keep_sharp=True;mod.weight=50;bpy.ops.object.modifier_apply(modifier=mod.name)
 return len(details)

changes=[];changed={}
for a in manifest['assets']:
 key=a['key'];ob=bpy.data.objects['SM_BN675_'+key];ds=[]
 if key=='MetalWallThick':
  left,right,bottom,top=-2.475,2.475,.025,2.475;w=.038
  polygons=[[(left,bottom),(right,bottom),(right-w,bottom+w),(left+w,bottom+w)],[(right,bottom),(right,top),(right-w,top-w),(right-w,bottom+w)],[(right,top),(left,top),(left+w,top-w),(right-w,top-w)],[(left,top),(left,bottom),(left+w,bottom+w),(left+w,top-w)]]
  for sign in [-1,1]:
   slot=0 if sign==-1 else 1
   for i,poly in enumerate(polygons):ds.append(rim('Mitered rim '+str(sign)+' '+str(i),poly,sign*.073,sign*.087,slot))
   for x in [-2.38,2.38]:
    for z in [.12,2.38]:ds.append(bolt('Corner fastener '+str((sign,x,z)),(x,sign*.075,z),(0,sign,0),.018,2))
 elif key in ['StructuralColumnA','HeavyColumnB']:
  w=.4 if key=='StructuralColumnA' else .5
  for x in [-w*.25,w*.25]:
   for z in [.045,2.455]:ds.append(bolt('Collar bolt '+str((x,z)),(x,-w/2,z),(0,-1,0),.014))
 elif key=='HorizontalBeamA':
  for x in [.12,4.88]:
   for z in [-.175,.175]:ds.append(bolt('Flange bolt '+str((x,z)),(x,-.2,z),(0,-1,0),.015))
 elif key.startswith('DoorFrameThick_'):
  t=a['thickness']+.06
  for x in [-.66,.66]:
   for z in [.18,2.10]:ds.append(bolt('Jamb anchor '+str((x,z)),(x,-t/2,z),(0,-1,0),.016,1))
 elif key=='HatchFrameThick':
  for x in [-.675,.675]:
   for y in [-.675,.675]:ds.append(bolt('Hatch anchor '+str((x,y)),(x,y,.02),(0,0,1),.016,1))
 elif 'JunctionPost_' in key or 'CornerJointPost_' in key:
  # Four front plate fasteners stay within X joint's 700-tris target.
  suffix=key.split('_')[-1];w={'Concrete':.34,'Metal':.19,'Reinforced':.44}[suffix]
  front=-w/2 if key.startswith('XJunctionPost_') else -(w-.012)/2
  for x in [-a['thickness']*.23,a['thickness']*.23]:
   for z in [.14,2.36]:ds.append(bolt('Joint anchor '+str((x,z)),(x,front,z),(0,-1,0),.013))
 elif key.startswith('WallEndCap_'):
  for z in [.14,2.36]:ds.append(bolt('Endcap anchor '+str(z),(.0225,0,z),(1,0,0),.013))
 elif key=='BeamEndCap':
  for y in [-.14,.14]:
   for z in [-.14,.14]:ds.append(bolt('Endplate bolt '+str((y,z)),(.025,y,z),(1,0,0),.016))
 elif key=='SlabEdgeTrim':
  for x in [.15,2.35]:ds.append(bolt('Edge anchor '+str(x),(x,-.0225,-.175),(0,-1,0),.014))
 elif key=='VerticalReinforcementTrim':
  for z in [.16,2.34]:ds.append(bolt('Trim anchor '+str(z),(0,-.047,z),(0,-1,0),.014))
 elif key=='HorizontalReinforcementTrim':
  for x in [.15,2.35]:ds.append(bolt('Angle anchor '+str(x),(x,-.038,-.08),(0,-1,0),.014))
 if not ds:continue
 from mathutils.bvhtree import BVHTree
 tree=BVHTree.FromPolygons([v.co for v in ob.data.vertices],[p.vertices for p in ob.data.polygons])
 seating=[]
 for name,vs,fs,slot in ds:
  if 'rim' in name:continue
  bottom=sum((Vector(v) for v in vs[:6]),Vector())/6;top=sum((Vector(v) for v in vs[-6:]),Vector())/6
  normal=(top-bottom).normalized();point=bottom+normal*.001
  hit,hn,face,distance=tree.ray_cast(point+normal*.02,-normal,.05)
  assert hit is not None and abs(distance-.02)<.0001,(key,name,distance)
  seating.append(dict(part=name,surfaceErrorMetres=abs(distance-.02),embeddedDepthMetres=.001))
 previous=a['tris'];append(ob,ds);changed[key]=ob.data
 bounds=[Vector(c) for c in ob.bound_box];lo=[min(c[i] for c in bounds) for i in range(3)];hi=[max(c[i] for c in bounds) for i in range(3)]
 a.update(quads=len(ob.data.polygons),tris=2*len(ob.data.polygons),boundsMin=lo,boundsMax=hi,dimensions=[hi[i]-lo[i] for i in range(3)])
 a['parts'].extend(d[0] for d in ds)
 a['detailNote']='Hardware visual only; structural collision and snapping reference unchanged.'
 bpy.ops.export_scene.fbx(filepath=str(assets/'Models'/('SM_BN675_'+key+'.fbx')),use_selection=True,object_types={'MESH'},apply_unit_scale=True,apply_scale_options='FBX_SCALE_UNITS',axis_forward='-Z',axis_up='Y',bake_space_transform=True,use_mesh_modifiers=True,mesh_smooth_type='OFF',use_tspace=True,add_leaf_bones=False,path_mode='RELATIVE')
 changes.append(dict(key=key,beforeTris=previous,afterTris=a['tris'],details=len(ds),boltSeatingChecks=seating))
 print('DETAIL_OK',key,previous,a['tris'],flush=True)
for im in bpy.data.images:im.filepath='//../Assets/BREAK_NORTH_M6_Architecture/Textures/'+im.name+'.png'
for ob in bpy.context.scene.objects:
 chosen=ob.name=='SM_BN675_MetalWallThick';ob.hide_set(not chosen);ob.select_set(chosen)
 if chosen:bpy.context.view_layer.objects.active=ob
bpy.ops.wm.save_as_mainfile(filepath=str(out/'BlenderSources/BN_M6_Architecture_Library.blend'))
# Transfer revised meshes into every copy in the existing comparison file.
bpy.ops.wm.open_mainfile(filepath=str(out/'ComparisonScenes/BN_M6_Assembly_And_Cut_References.blend'))
bpy.context.preferences.filepaths.save_version=0
with bpy.data.libraries.load(str(out/'BlenderSources/BN_M6_Architecture_Library.blend'),link=False) as (src,dst):dst.objects=['SM_BN675_'+c['key'] for c in changes]
incoming={o['asset_key']:o for o in dst.objects}
for ob in list(bpy.data.objects):
 key=ob.get('asset_key')
 if key in incoming and ob!=incoming[key]:ob.data=incoming[key].data
for im in bpy.data.images:
 if im.packed_file:im.filepath='//../Assets/BREAK_NORTH_M6_Architecture/Textures/'+im.name.split('.00')[0]+'.png'
bpy.ops.wm.save_as_mainfile(filepath=str(out/'ComparisonScenes/BN_M6_Assembly_And_Cut_References.blend'))
(assets/'KitManifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(out/'Reports/Hardware_V3_Changes.json').write_text(json.dumps(changes,indent=2),encoding='utf-8')
shutil.copy2(__file__,out/'RebuildScripts/detail_art_v3.py')
print('V3_DETAIL_COMPLETE',len(changes),flush=True)
