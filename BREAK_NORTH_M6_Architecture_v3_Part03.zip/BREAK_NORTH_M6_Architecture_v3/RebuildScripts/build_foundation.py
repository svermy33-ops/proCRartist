"""Reproducible BREAK NORTH M6 Architectural Foundation. Blender 5.2."""
import bpy, bmesh, numpy as np, math, json, pathlib, traceback
from mathutils import Vector

ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs'/'BREAK_NORTH_M6_Architecture_v1'
AS=OUT/'Assets'/'BREAK_NORTH_M6_Architecture'
for p in [OUT/'BlenderSources',OUT/'ComparisonScenes',OUT/'Reports',AS/'Models',AS/'Textures',AS/'Editor']:
    p.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
S=1024
rng=np.random.default_rng(675)
y,x=np.mgrid[0:S,0:S].astype(np.float32)/S

def noise(freq):
    g=rng.random((freq,freq)).astype(np.float32)
    px=x*freq; py=y*freq; ix=px.astype(int); iy=py.astype(int)
    fx=px-ix; fy=py-iy; fx=fx*fx*(3-2*fx); fy=fy*fy*(3-2*fy)
    return (g[iy%freq,ix%freq]*(1-fx)*(1-fy)+g[iy%freq,(ix+1)%freq]*fx*(1-fy)+g[(iy+1)%freq,ix%freq]*(1-fx)*fy+g[(iy+1)%freq,(ix+1)%freq]*fx*fy)

def save_image(name,values,data=False):
    rgba=np.ones((S,S,4),np.float32)
    if values.ndim==2: rgba[:,:,:3]=values[:,:,None]
    else: rgba[:,:,:values.shape[2]]=values
    im=bpy.data.images.new(name,width=S,height=S,alpha=True)
    im.colorspace_settings.name='Non-Color' if data else 'sRGB'
    im.pixels.foreach_set(rgba.ravel())
    im.filepath_raw=str(AS/'Textures'/f'{name}.png'); im.file_format='PNG'; im.save()
    return im

families={}
for idx,name in enumerate(['ConcreteSurfaceNeutral','ConcreteInterior','PaintedMetalNeutral','BareCutMetal','StructuralSteel','FloorNeutral','CeilingNeutral','ReinforcedInterior']):
    macro=noise(5); med=noise(44); fine=noise(210); grain=noise(480)
    steel=name in ['BareCutMetal','StructuralSteel']; paint=name=='PaintedMetalNeutral'
    interior='Interior' in name
    metal=np.zeros((S,S),np.float32)
    if steel:
        brushed=(np.sin(y*math.tau*360)+np.sin(y*math.tau*191+x*math.tau*3))*.5
        height=(fine-.5)*.000035+brushed*.000013
        base=.48+(macro-.5)*.055+brushed*.022+(grain-.5)*.035
        rough=.34+(med-.5)*.19; metal[:]=.96
    elif paint:
        height=(fine-.5)*.00010+(grain-.5)*.00004
        base=.72+(macro-.5)*.026+(fine-.5)*.016
        rough=.45+(med-.5)*.10
        # Sparse short tool marks, periodic and without large repeated damage.
        scratches=np.zeros((S,S),np.float32)
        for k in range(30):
            cx,cy=rng.random(2); length=rng.uniform(.002,.014)
            dx=np.minimum(abs(x-cx),1-abs(x-cx)); dy=np.minimum(abs(y-cy),1-abs(y-cy))
            scratches=np.maximum(scratches,np.exp(-((dy/.0007)**2))*np.clip(1-dx/length,0,1))
        height-=scratches*.00018; base-=scratches*.12; rough+=scratches*.12
    else:
        n=42 if interior else 75
        gx=x*n; gy=y*n; ix=gx.astype(int); iy=gy.astype(int)
        centers=rng.random((n,n,2)); shades=rng.random((n,n))
        nearest=np.full((S,S),100.,np.float32); stone=np.zeros((S,S),np.float32)
        for dy in [-1,0,1]:
            for dx in [-1,0,1]:
                qx=(ix+dx)%n; qy=(iy+dy)%n
                d=(gx-(ix+dx+centers[qy,qx,0]))**2+(gy-(iy+dy+centers[qy,qx,1]))**2
                take=d<nearest; stone=np.where(take,shades[qy,qx],stone); nearest=np.minimum(nearest,d)
        aggregate=np.clip((.22-nearest)*6,0,1)
        pits=np.clip((.24-fine)*6,0,1)
        if interior:
            height=(med-.5)*.0013+aggregate*(stone-.3)*.0018-pits*.00065
            base=.46+(macro-.5)*.10+aggregate*(stone-.55)*.23+(grain-.5)*.06
            rough=.83+(stone-.5)*.13
        else:
            height=(fine-.5)*.00014-pits*.00025+aggregate*.00008
            base=.70+(macro-.5)*.075+(med-.5)*.035+(grain-.5)*.03-pits*.05
            rough=.73+(med-.5)*.14
        if name=='FloorNeutral': base-=.05; rough-=.1
        if name=='CeilingNeutral': base+=.065
        if name=='ReinforcedInterior':
            # Occasional exposed aggregate with more contrast; rebar is not baked in.
            base-=.045; height+=(med-.5)*.0005
    du=(np.roll(height,-1,1)-np.roll(height,1,1))/(4/S)
    dv=(np.roll(height,-1,0)-np.roll(height,1,0))/(4/S)
    normal=np.stack([-du,-dv,np.ones_like(du)],2); normal/=np.linalg.norm(normal,axis=2)[:,:,None]
    ms=np.zeros((S,S,4),np.float32); ms[:,:,0]=metal; ms[:,:,3]=1-np.clip(rough,0,1)
    families[name]={
        'BaseColor':save_image(name+'_BaseColor',np.clip(base,0,1)),
        'Normal':save_image(name+'_Normal',normal*.5+.5,True),
        'MetallicSmoothness':save_image(name+'_MetallicSmoothness',ms,True)}
    print('TEXTURE_OK',name,flush=True)

materials={}
def material(asset,role,family):
    name=f'BN675_{asset}_{role}'
    if name in materials:return materials[name]
    m=bpy.data.materials.new(name); m.use_nodes=True
    nt=m.node_tree; bs=nt.nodes.get('Principled BSDF')
    bc=nt.nodes.new('ShaderNodeTexImage');bc.image=families[family]['BaseColor'];nt.links.new(bc.outputs['Color'],bs.inputs['Base Color'])
    no=nt.nodes.new('ShaderNodeTexImage');no.image=families[family]['Normal']
    nm=nt.nodes.new('ShaderNodeNormalMap');nm.inputs['Strength'].default_value=1
    nt.links.new(no.outputs['Color'],nm.inputs['Color']);nt.links.new(nm.outputs['Normal'],bs.inputs['Normal'])
    ms=nt.nodes.new('ShaderNodeTexImage');ms.image=families[family]['MetallicSmoothness']
    sep=nt.nodes.new('ShaderNodeSeparateColor');nt.links.new(ms.outputs['Color'],sep.inputs['Color']);nt.links.new(sep.outputs['Red'],bs.inputs['Metallic'])
    inv=nt.nodes.new('ShaderNodeMath');inv.operation='SUBTRACT';inv.inputs[0].default_value=1
    nt.links.new(ms.outputs['Alpha'],inv.inputs[1]);nt.links.new(inv.outputs[0],bs.inputs['Roughness'])
    m['family']=family; materials[name]=m; return m

def box_part(name,center,size,bevel=.008,selector=None,slot=0):
    """Rounded cuboid: six 3x3 quad patches, welded closed, no triangular corner caps."""
    h=np.array(size,dtype=float)/2; b=min(bevel,float(min(h))*.24)
    coords=[[-t,-t+b,t-b,t] for t in h]
    verts=[]; faces=[]; slots=[]; lookup={}
    for axis in range(3):
        other=[a for a in range(3) if a!=axis]
        for sign in [-1,1]:
            grid={}
            for i in range(4):
                for j in range(4):
                    p=np.zeros(3);p[axis]=sign*h[axis];p[other[0]]=coords[other[0]][i];p[other[1]]=coords[other[1]][j]
                    inner=np.clip(p,-h+b,h-b);delta=p-inner; p=inner+delta/np.linalg.norm(delta)*b
                    key=tuple(np.round(p,8))
                    if key not in lookup:lookup[key]=len(verts);verts.append(tuple(p+center))
                    grid[i,j]=lookup[key]
            for i in range(3):
                for j in range(3):
                    faces.append([grid[i,j],grid[i+1,j],grid[i+1,j+1],grid[i,j+1]])
                    slots.append(selector(axis,sign) if selector else slot)
    return dict(name=name,verts=verts,faces=faces,slots=slots,center=list(center),size=list(size))

records=[]; models={}
def model(key,category,parts,fams,roles,pivot,target,thickness=0,fixture=False):
    vs=[];fs=[];mi=[];ranges=[]
    for p in parts:
        n=len(vs);vs.extend(p['verts']);fs.extend([[v+n for v in f] for f in p['faces']]);mi.extend(p['slots']);ranges.append((p['name'],n,len(vs)))
    mesh=bpy.data.meshes.new(key);mesh.from_pydata(vs,[],fs);mesh.update()
    ob=bpy.data.objects.new('SM_BN675_'+key,mesh);bpy.context.collection.objects.link(ob)
    for role,fam in zip(roles,fams):mesh.materials.append(material(key,role,fam))
    for poly,slot in zip(mesh.polygons,mi):poly.material_index=slot;poly.use_smooth=True
    bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(mesh);bm.free()
    for name,start,end in ranges:ob.vertex_groups.new(name=name).add(list(range(start,end)),1,'REPLACE')
    uv=mesh.uv_layers.new(name='UV0_Material')
    for p in mesh.polygons:
        a=max(range(3),key=lambda a:abs(p.normal[a]));sg=1 if p.normal[a]>=0 else -1
        for li in p.loop_indices:
            co=mesh.vertices[mesh.loops[li].vertex_index].co
            # Right-handed planar frames: du cross dv follows the surface normal.
            if a==0:u,v=sg*co.y,co.z
            elif a==1:u,v=-sg*co.x,co.z
            else:u,v=co.x,sg*co.y
            uv.data[li].uv=(u/2,v/2)
    mesh.uv_layers.new(name='UV1_Lightmap')
    bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
    mesh.uv_layers.active_index=1
    bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=math.radians(66),island_margin=.035);bpy.ops.object.mode_set(mode='OBJECT')
    mesh.uv_layers.active_index=0;mesh.uv_layers[0].active_render=True
    mod=ob.modifiers.new('Weighted face normals','WEIGHTED_NORMAL');mod.keep_sharp=True;mod.weight=50
    bpy.ops.object.modifier_apply(modifier=mod.name)
    ob['asset_key']=key;ob['pivot']=pivot;ob['metres_per_uv']=2.;ob['category']=category
    bb=[Vector(c) for c in ob.bound_box];lo=[min(c[a] for c in bb) for a in range(3)];hi=[max(c[a] for c in bb) for a in range(3)]
    rec=dict(key=key,category=category,fixture=fixture,pivot=pivot,thickness=thickness,dimensions=[hi[a]-lo[a] for a in range(3)],boundsMin=lo,boundsMax=hi,quads=len(mesh.polygons),tris=sum(len(p.vertices)-2 for p in mesh.polygons),target=target,roles=roles,families=fams,materialNames=[m.name for m in mesh.materials],colliders=[dict(center=p['center'],size=p['size']) for p in parts],parts=[p['name'] for p in parts])
    records.append(rec);models[key]=ob
    return ob

wall_sel=lambda a,s: (0 if s==-1 else 1) if a==1 else 2
slab_sel=lambda a,s: (0 if s==1 else 1) if a==2 else 2
WALLS=[('ConcreteWallThick',.30,'ConcreteSurfaceNeutral','ConcreteInterior'),('MetalWallThick',.15,'PaintedMetalNeutral','BareCutMetal'),('ReinforcedWallThick',.40,'ConcreteSurfaceNeutral','ReinforcedInterior')]
for key,t,fa,fi in WALLS:
    model(key,'Wall',[box_part('Closed structural wall',(0,0,1.25),(5,t,2.5),.005,wall_sel)],[fa,fa,fi],['FaceA','FaceB','Interior'],'bottom-center',[100,500],t)
model('FloorCeilingSlab','Slab',[box_part('Solid slab',(0,0,-.175),(2.5,2.5,.35),.005,slab_sel)],['FloorNeutral','CeilingNeutral','ConcreteInterior'],['Top','Bottom','Interior'],'top-center',[100,400],.35)

def structure(key,w,category='Column',height=2.5):
    # Collar remains within declared maximum width for predictable wall termination.
    parts=[box_part('Box steel core',(0,0,height/2),(w-.025,w-.025,height),.009),box_part('Base collar',(0,0,.045),(w,w,.09),.006),box_part('Head collar',(0,0,height-.045),(w,w,.09),.006)]
    return model(key,category,parts,['StructuralSteel'],['Structural'],'bottom-center',[150,1000] if w>=.5 else [150,700])
structure('StructuralColumnA',.4);structure('HeavyColumnB',.5)
model('HorizontalBeamA','Beam',[box_part('Web',(2.5,0,0),(5,.10,.30),.006),box_part('Upper flange',(2.5,0,.175),(5,.4,.05),.005),box_part('Lower flange',(2.5,0,-.175),(5,.4,.05),.005)],['StructuralSteel'],['Structural'],'connection-end center',[150,700])

for suffix,t,postw in [('Concrete',.30,.34),('Metal',.15,.19),('Reinforced',.40,.44)]:
    for kind,directions in [('CornerJointPost',[(1,0),(0,1)]),('TJunctionPost',[(-1,0),(1,0),(0,1)]),('XJunctionPost',[(-1,0),(1,0),(0,-1),(0,1)])]:
        # Plates are physical attachment flanges, seated in the continuous core.
        parts=[box_part('Continuous joint core',(0,0,1.25),(postw-.012,postw-.012,2.5),.006)]
        for i,(dx,dy) in enumerate(directions):
            center=(dx*(postw/2-.009),dy*(postw/2-.009),1.25)
            size=(.018,t+.014,2.5) if dx else (t+.014,.018,2.5)
            parts.append(box_part('Wall attachment '+str(i),center,size,.003))
        model(kind+'_'+suffix,kind,parts,['StructuralSteel'],['Structural'],'bottom-center; wall ends at +/- '+str(postw/2)+'m',[150,700],t)
    interior='BareCutMetal' if suffix=='Metal' else ('ReinforcedInterior' if suffix=='Reinforced' else 'ConcreteInterior')
    model('WallEndCap_'+suffix,'WallEndCap',[box_part('End closure',(0,0,1.25),(.045,t,2.5),.003,lambda a,s:1 if a==0 and s==-1 else 0)],['StructuralSteel',interior],['Exterior','Interior'],'bottom-center; -X mating surface at -0.0225m',[0,500],t)
    depth=t+.06
    doorparts=[box_part('Left jamb',(-.66,0,1.175),(.12,depth,2.35),.006,lambda a,s:1 if a==0 and s==1 else 0),box_part('Right jamb',(.66,0,1.175),(.12,depth,2.35),.006,lambda a,s:1 if a==0 and s==-1 else 0),box_part('Lintel',(0,0,2.29),(1.2,depth,.12),.006,lambda a,s:1 if a==2 and s==-1 else 0),box_part('Left foot',(-.66,0,.06),(.125,depth+.012,.12),.004),box_part('Right foot',(.66,0,.06),(.125,depth+.012,.12),.004)]
    model('DoorFrameThick_'+suffix,'DoorFrameThick',doorparts,['StructuralSteel','BareCutMetal'],['Frame','Interior'],'opening base center; clear 1.2m x 2.23m',[400,1200],t)

parts=[box_part('Left side',(-.675,0,-.175),(.15,1.5,.39),.005,lambda a,s:1 if a==0 and s==1 else 0),box_part('Right side',(.675,0,-.175),(.15,1.5,.39),.005,lambda a,s:1 if a==0 and s==-1 else 0),box_part('Near side',(0,-.675,-.175),(1.2,.15,.39),.005,lambda a,s:1 if a==1 and s==1 else 0),box_part('Far side',(0,.675,-.175),(1.2,.15,.39),.005,lambda a,s:1 if a==1 and s==-1 else 0)]
model('HatchFrameThick','HatchFrameThick',parts,['StructuralSteel','BareCutMetal'],['Frame','Interior'],'slab top / opening center; clear 1.2m square',[400,1200],.35)
model('SlabEdgeTrim','SlabEdgeTrim',[box_part('Edge web',(1.25,0,-.175),(2.5,.045,.35),.004),box_part('Top return',(1.25,.045,.006),(2.5,.13,.018),.003)],['StructuralSteel'],['Structural'],'edge at Y=0, slab top Z=0; +Y return',[100,500],.35)
model('VerticalReinforcementTrim','VerticalReinforcementTrim',[box_part('Hat web',(0,-.027,1.25),(.12,.04,2.5),.004),box_part('Left flange',(-.08,-.008,1.25),(.065,.02,2.5),.003),box_part('Right flange',(.08,-.008,1.25),(.065,.02,2.5),.003)],['StructuralSteel'],['Structural'],'wall bottom at rear mounting plane Y=0',[100,500])
model('HorizontalReinforcementTrim','HorizontalReinforcementTrim',[box_part('Angle web',(1.25,-.018,-.08),(2.5,.04,.16),.003),box_part('Angle return',(1.25,-.065,-.009),(2.5,.13,.022),.003)],['StructuralSteel'],['Structural'],'left end at wall-ceiling contact',[100,500])
model('BeamEndCap','BeamEndCap',[box_part('End plate',(.0125,0,0),(.025,.42,.42),.004)],['StructuralSteel'],['Structural'],'beam end plane X=0',[0,500])

# Reusable static geometry only for assembly and destruction reference scenes.
def fixture_wall(key,w,h=2.5):
    model(key,'TestFixture',[box_part('Closed reference wall',(0,0,h/2),(w,.3,h),.004,wall_sel)],['ConcreteSurfaceNeutral','ConcreteSurfaceNeutral','ConcreteInterior'],['FaceA','FaceB','Interior'],'bottom-center',[0,500],.3,True)
fixture_wall('Fixture_DoorLintel',1.44,.15)
fixture_wall('Fixture_WallSide',1.75)
fixture_wall('Fixture_WallTop',1.5,.65)
fixture_wall('Fixture_WallBottom',1.5,.55)
for key,w,d in [('Fixture_SlabSide',.5,2.5),('Fixture_SlabEnd',1.5,.5)]:
    model(key,'TestFixture',[box_part('Closed opening slab',(0,0,-.175),(w,d,.35),.004,slab_sel)],['FloorNeutral','CeilingNeutral','ConcreteInterior'],['Top','Bottom','Interior'],'top-center',[0,400],.35,True)

manifest=dict(version='M6_Architecture_v1',metresPerUV=2,normalConvention='OpenGL +Y tangent-space',assets=records,scenes=[])
def scene(name,placements):
    # positions/rotations are Blender coordinates, Unity builder converts explicitly.
    manifest['scenes'].append(dict(name=name,placements=[dict(key=k,position=list(p),rotationZ=r) for k,p,r in placements]))
cw='ConcreteWallThick';cp='CornerJointPost_Concrete';tj='TJunctionPost_Concrete';xj='XJunctionPost_Concrete'
scene('A_Straight',[('StructuralColumnA',(-2.7,0,0),0),(cw,(0,0,0),0),('StructuralColumnA',(2.7,0,0),0)])
corner=[(cp,(0,0,0),0),(cw,(2.67,0,0),0),(cw,(0,2.67,0),90)]
scene('B_Corner',corner)
scene('C_T_Junction',[(tj,(0,0,0),0),(cw,(-2.67,0,0),0),(cw,(2.67,0,0),0),(cw,(0,2.67,0),90)])
scene('D_X_Junction',[(xj,(0,0,0),0)]+[(cw,(dx*2.67,dy*2.67,0),90 if dy else 0) for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]])
scene('E_Slab_Structure',[('StructuralColumnA',(0,0,0),0),('StructuralColumnA',(5.4,0,0),0),('HorizontalBeamA',(.2,0,2.3),0),('FloorCeilingSlab',(1.35,0,2.85),0),('FloorCeilingSlab',(3.85,0,2.85),0)])
scene('F_Door',[(cw,(-3.22,0,0),0),(cw,(3.22,0,0),0),('DoorFrameThick_Concrete',(0,0,0),0),('Fixture_DoorLintel',(0,0,2.35),0)])
hole=[('Fixture_SlabSide',(-1,0,0),0),('Fixture_SlabSide',(1,0,0),0),('Fixture_SlabEnd',(0,-1,0),0),('Fixture_SlabEnd',(0,1,0),0)]
scene('G_Hatch',hole+[('HatchFrameThick',(0,0,0),0)])
broken=[('Fixture_WallSide',(-1.625,0,0),0),('Fixture_WallSide',(1.625,0,0),0),('Fixture_WallTop',(0,0,1.85),0),('Fixture_WallBottom',(0,0,0),0)]
scene('Destruction_01_WallCenter',broken)
scene('Destruction_02_WallEdge',[('StructuralColumnA',(-2.7,0,0),0),('Fixture_WallSide',(1.625,0,0),0),('Fixture_WallTop',(0,0,1.85),0)])
scene('Destruction_03_CornerOneSide',corner[:1]+corner[2:])
scene('Destruction_04_CornerBothSides',corner[:1])
scene('Destruction_05_TJunction',[(tj,(0,0,0),0),(cw,(0,2.67,0),90),('Fixture_WallSide',(4.295,0,0),0)])
scene('Destruction_06_FloorHole',hole)
scene('Destruction_07_CeilingHole',[(k,(p[0],p[1],2.85),r) for k,p,r in hole])

def validate(ob):
    me=ob.data;bm=bmesh.new();bm.from_mesh(me)
    badquad=sum(len(p.vertices)!=4 for p in me.polygons)
    boundary=sum(not e.is_manifold for e in bm.edges)
    zero=sum(f.calc_area()<1e-12 for f in bm.faces)
    twisted=0
    for p in me.polygons:
        a,b,c,d=[me.vertices[v].co for v in p.vertices]
        n1=(b-a).cross(c-a);n2=(c-a).cross(d-a)
        if n1.length<1e-10 or n2.length<1e-10 or n1.dot(n2)<=0:twisted+=1
    bm.free()
    uvzero=[]
    for layer in me.uv_layers:
        z=0
        for p in me.polygons:
            u=[layer.data[i].uv for i in p.loop_indices]
            area=abs(sum(u[i].x*u[(i+1)%4].y-u[(i+1)%4].x*u[i].y for i in range(4)))*.5
            if area<1e-12 or not all(math.isfinite(t) for v in u for t in v):z+=1
        uvzero.append(z)
    assert not (badquad or boundary or zero or twisted or any(uvzero)),(ob.name,badquad,boundary,zero,twisted,uvzero)
    me.calc_tangents(uvmap=me.uv_layers[0].name)
    assert all(math.isfinite(v) for l in me.loops for v in l.tangent)
    return dict(nonQuads=badquad,nonManifoldEdges=boundary,zeroFaces=zero,twistedQuads=twisted,invalidUVFaces=uvzero,finiteTangents=True)

checks=[]
for rec in records:
    ob=models[rec['key']]; checks.append(dict(key=rec['key'],source=validate(ob)))
    bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
    bpy.ops.export_scene.fbx(filepath=str(AS/'Models'/f'{ob.name}.fbx'),use_selection=True,object_types={'MESH'},apply_unit_scale=True,apply_scale_options='FBX_SCALE_UNITS',axis_forward='-Z',axis_up='Y',bake_space_transform=True,use_mesh_modifiers=True,mesh_smooth_type='OFF',use_tspace=True,add_leaf_bones=False,path_mode='RELATIVE')
    print('EXPORT_OK',rec['key'],rec['tris'],flush=True)

# Editable library scene. Vertex groups retain functional part selection.
library=bpy.context.scene;library.name='Asset_Library_AtOrigin';library.unit_settings.system='METRIC'
for im in bpy.data.images:
    if im.source=='FILE':im.pack()
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'BlenderSources'/'BN_M6_Architecture_Library.blend'))
for desc in manifest['scenes']:
    sc=bpy.data.scenes.new(desc['name']);sc.unit_settings.system='METRIC'
    for i,p in enumerate(desc['placements']):
        ob=models[p['key']].copy();ob.data=ob.data.copy();ob.name=p['key']+'_'+str(i);sc.collection.objects.link(ob);ob.location=p['position'];ob.rotation_euler.z=math.radians(p['rotationZ'])
        # Source UVs remain local, 2 metres per period. Runtime world-UV rules are documented separately.
    sc['purpose']='Static assembly / cut-surface reference. No runtime destruction or networking.'
catalog=bpy.data.scenes.new('00_Catalog')
for i,rec in enumerate(r for r in records if not r['fixture']):
    ob=models[rec['key']].copy();catalog.collection.objects.link(ob);ob.location=((i%5)*7,(i//5)*5,0)
bpy.context.window.scene=catalog
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'ComparisonScenes'/'BN_M6_Assembly_And_Cut_References.blend'))

# Round-trip each exported file into a clean temporary scene.
rt=bpy.data.scenes.new('RoundTrip');bpy.context.window.scene=rt
for rec,check in zip(records,checks):
    bpy.ops.import_scene.fbx(filepath=str(AS/'Models'/('SM_BN675_'+rec['key']+'.fbx')),use_custom_normals=True)
    imported=[o for o in rt.objects if o.type=='MESH'];assert len(imported)==1
    ob=imported[0];src=models[rec['key']]
    bpy.context.view_layer.update()
    world=[ob.matrix_world@Vector(c) for c in ob.bound_box]
    dims=[max(c[a] for c in world)-min(c[a] for c in world) for a in range(3)]
    err=max(abs(dims[a]-rec['dimensions'][a]) for a in range(3))
    assert err<.0001,(rec['key'],dims,rec['dimensions'])
    assert len(ob.data.polygons)==rec['quads']
    assert len(ob.data.uv_layers)==2
    assert len(ob.data.materials)==len(rec['roles'])
    assert ob.location.length<.0001
    from mathutils.kdtree import KDTree
    kd=KDTree(len(src.data.vertices))
    for v in src.data.vertices:kd.insert(v.co,v.index)
    kd.balance()
    vertex_error=max(kd.find(ob.matrix_world@v.co)[2] for v in ob.data.vertices)
    assert vertex_error<.0001,(rec['key'],vertex_error)
    check['fbx']=dict(dimensionErrorMetres=err,maxWorldVertexErrorMetres=vertex_error,quads=len(ob.data.polygons),uvChannels=2,materialSlots=len(ob.data.materials),pivotErrorMetres=ob.location.length,validation=validate(ob))
    bpy.data.objects.remove(ob,do_unlink=True)
    print('ROUNDTRIP_OK',rec['key'],flush=True)
(AS/'KitManifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(OUT/'Reports'/'Geometry_And_FBX_Checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print('BUILD_FOUNDATION_COMPLETE',len(records),flush=True)
