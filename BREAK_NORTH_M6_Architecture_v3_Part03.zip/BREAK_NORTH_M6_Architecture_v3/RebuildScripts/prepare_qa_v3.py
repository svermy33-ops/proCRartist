import pathlib
r=pathlib.Path(__file__).resolve().parents[1]
s=(r/'work/qa_foundation.py').read_text(encoding='utf-8').replace('BREAK_NORTH_M6_Architecture_v1','BREAK_NORTH_M6_Architecture_v3')
s=s.replace('faces={poly_sig(src,p):p for p in me.polygons}',"faces={}\n    for p in me.polygons:faces.setdefault(poly_sig(src,p),[]).append(p)")
s=s.replace('sp=faces[poly_sig(imp,p)]',"candidates=faces[poly_sig(imp,p)]\n        direction=(imp.matrix_world.to_3x3()@p.normal).normalized()\n        sp=max(candidates,key=lambda f:f.normal.dot(direction))\n        assert sp.normal.dot(direction)>.999")
s=s.replace("print('DEEP_QA_COMPLETE',len(qa),len(tex),flush=True)",'''print('DEEP_QA_COMPLETE',len(qa),len(tex),flush=True)
import ast,bmesh
script=ast.parse((ROOT/'work/build_foundation.py').read_text(encoding='utf-8'))
fn=next(n for n in script.body if isinstance(n,ast.FunctionDef) and n.name=='validate')
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<validate>','exec'))
results=[]
for a in manifest['assets']:
 ob=bpy.data.objects['SM_BN675_'+a['key']]
 results.append(dict(key=a['key'],source=validate(ob),quads=len(ob.data.polygons),tris=2*len(ob.data.polygons)))
 assert len(ob.data.polygons)==a['quads']
 assert 2*len(ob.data.polygons)==a['tris']
(OUT/'Reports'/'Geometry_And_FBX_Checks.json').write_text(json.dumps(results,indent=2))
print('V3_TOPOLOGY_COMPLETE',len(results),flush=True)
''')
(r/'work/qa_art_v3.py').write_text(s,encoding='utf-8')
