import bpy,pathlib,json
from mathutils import Vector,Quaternion
root=pathlib.Path(__file__).resolve().parents[1]/'outputs'/'BREAK_NORTH_M6_Architecture_v1'
for folder,filename in [('BlenderSources','BN_M6_Architecture_Library.blend'),('ComparisonScenes','BN_M6_Assembly_And_Cut_References.blend')]:
    path=root/folder/filename;bpy.ops.wm.open_mainfile(filepath=str(path))
    bpy.context.preferences.filepaths.save_version=0
    for image in bpy.data.images:
        image.filepath='//../Assets/BREAK_NORTH_M6_Architecture/Textures/'+image.name+'.png'
        assert image.packed_file
        assert len(image.pixels)==1024*1024*4
    if folder=='BlenderSources':
        for ob in bpy.context.scene.objects:
            chosen=ob.name=='SM_BN675_ConcreteWallThick';ob.hide_set(not chosen);ob.select_set(chosen)
            if chosen:bpy.context.view_layer.objects.active=ob
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type=='VIEW_3D':
                area.spaces.active.region_3d.view_distance=9 if folder=='BlenderSources' else 38
                area.spaces.active.region_3d.view_location=Vector((0,0,1.25)) if folder=='BlenderSources' else Vector((13,12,0))
    bpy.ops.wm.save_as_mainfile(filepath=str(path))
    print('SOURCE_PACK_OK',filename,len(bpy.data.images),flush=True)
