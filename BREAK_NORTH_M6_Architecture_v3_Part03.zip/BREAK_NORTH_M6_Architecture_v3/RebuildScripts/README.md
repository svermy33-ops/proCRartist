# Rebuild

Dependencies: Blender 5.2.1 (bpy, bmesh, bundled numpy). No downloaded texture assets.

To reproduce the delivered workspace layout, create a working folder with a `work` subfolder, copy the Python files into `work`, and copy the delivered `Assets` folder into `outputs/BREAK_NORTH_M6_Architecture_v1/Assets` so the Unity Editor source is preserved. Run from that working folder:

```
blender -b -t 4 --python-exit-code 1 --python work/build_foundation.py
blender -b -t 4 --python-exit-code 1 --python work/qa_foundation.py
blender -b -t 2 --python-exit-code 1 --python work/finalize_sources.py
python work/deliver_foundation.py
```

The scripts derive their working root from their parent directory. Output is created under that root's `outputs/BREAK_NORTH_M6_Architecture_v1`. Run in a scratch copy to preserve delivered files. Success markers are BUILD_FOUNDATION_COMPLETE, DEEP_QA_COMPLETE, SOURCE_PACK_OK and DELIVERY_COMPLETE. The final packaging script needs only Python standard library. No preview render is generated.

## v2 revision
The original build scripts reproduce v1. After reproducing v1, copy revise_art_v2.py into the working root work/ folder and run it with Blender to create the sibling v2 folder. The v2 revision updates textures, both packed Blender sources and the Unity default palette.

## v2 revision
The original build scripts reproduce v1. After reproducing v1, copy revise_art_v2.py into the working root work/ folder and run it with Blender to create the sibling v2 folder. The v2 revision updates textures, both packed Blender sources and the Unity default palette.

## v3
After v2 is present in outputs, run work/detail_art_v3.py with Blender. Then run prepare_qa_v3.py with Python, qa_art_v3.py with Blender, and package_art_v3.py with Python. These preserve v2 and create v3.
