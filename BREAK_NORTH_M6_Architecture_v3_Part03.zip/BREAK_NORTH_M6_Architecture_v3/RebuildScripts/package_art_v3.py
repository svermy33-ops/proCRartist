import pathlib,json,hashlib,zipfile,shutil
r=pathlib.Path(__file__).resolve().parents[1];o=r/'outputs/BREAK_NORTH_M6_Architecture_v3';old=r/'outputs/BREAK_NORTH_M6_Architecture_v2';a=o/'Assets/BREAK_NORTH_M6_Architecture'
log=(r/'work/qa_art_v3.log').read_text(encoding='utf-8');assert 'DEEP_QA_COMPLETE 33 24' in log and 'V3_TOPOLOGY_COMPLETE 33' in log and 'Traceback' not in log
m=json.loads((a/'KitManifest.json').read_text(encoding='utf-8'));changes=json.loads((o/'Reports/Hardware_V3_Changes.json').read_text(encoding='utf-8'))
assert m['defaultTintSRGB']==json.loads((old/'Assets/BREAK_NORTH_M6_Architecture/KitManifest.json').read_text(encoding='utf-8'))['defaultTintSRGB']
for p in (a/'Textures').glob('*.png'):assert p.read_bytes()==(old/p.relative_to(o)).read_bytes()
assert (a/'Editor/BN675ArchitectureImporter.cs').read_bytes()==(old/'Assets/BREAK_NORTH_M6_Architecture/Editor/BN675ArchitectureImporter.cs').read_bytes()
readme='''# BREAK NORTH — M6 Architecture v3

## 이번 수정

금속 벽 양면에 얇은 45° 맞댐 테두리와 모서리 육각 체결부를 추가했습니다. 기둥 collar, 빔 flange, 금속 joint, 문틀/해치틀, end cap, reinforcement trim에도 기능적인 볼트를 추가했습니다. 콘크리트 표면에는 볼트를 추가하지 않았습니다. Concrete/Reinforced 이름의 joint/frame도 재질은 강철이므로 체결부 대상에 포함합니다.

- 금속 벽 108 → 460 tris. 양면 테두리 각 4개 및 체결부 각 4개.
- 기둥·빔 324 → 452 tris, 문틀 540 → 668 tris, 해치틀 432 → 560 tris.
- X joint 540 → 668 tris. 모든 항목은 기존 목표 상한 이내.
- 기본 모델 27개 + 참고용 6개는 유지. 그중 금속 부품이 있는 24개 수정.
- **v2 텍스처 24장 및 기본 tint 팔레트는 바이트/값 동일성을 확인했습니다.** 기존 표면의 색·질감 설정을 변경하지 않았습니다.

테두리는 기존 Face A/B의 도장 재질을 사용합니다. 금속 벽 나사는 기존 Interior의 BareCutMetal, 문틀/해치 나사는 기존 bare metal slot을 공유합니다. 다른 강철 체결부는 기존 Structural slot을 공유합니다. 추가 재질 슬롯이나 draw call은 만들지 않았습니다. 체결부는 작은 bevel이 있는 닫힌 육각 머리이며 나사산·십자 홈은 모델링하지 않았습니다.

## 텍스처 PNG의 색이 덜 살아 보이는 이유

텍스처는 중립색 BaseColor이고, 최종 기본 색은 Blender의 `Handoff_Default_Tint` multiply node / Unity Material의 Base Color(Color)에 있습니다.

`표면의 기본색 = 중립 BaseColor × 재질 tint`

따라서 PNG만 열면 베이지·청회색 팔레트가 보이지 않는 것이 정상입니다. Normal은 표면 방향, MetallicSmoothness는 R=금속성/A=매끄러움인 데이터 파일이라 색상 이미지로 판단하지 않습니다. 실제 화면은 조명·환경 반사·톤매핑에도 영향을 받습니다. 중립 텍스처 공유 방식은 색상별 FBX/텍스처 복제를 피하고 Face A/B의 테마를 독립적으로 바꾸기 위한 설계입니다. 컬러를 PNG에 다시 칠하고 tint를 그대로 두면 색이 이중으로 적용됩니다.

## Unity 적용

1. `Assets/BREAK_NORTH_M6_Architecture` 전체를 프로젝트의 같은 경로로 복사합니다. 기존 `.meta`는 보존합니다.
2. 임포트/컴파일 후 `BREAK NORTH > M6 Architecture > 1 - Build Materials and Prefabs` 실행.
3. `2 - Validate Imported Prefabs`로 실제 Unity 치수·재질·collider를 확인합니다.
4. `3 - Create Assembly and Cut Reference Scene`으로 새 참고 scene을 만듭니다. 이전에 생성했던 scene/Prefab Variant의 override는 프로젝트에서 확인하세요.

v2와 같은 기본 팔레트가 적용됩니다. 메뉴 1은 이 기본 팔레트를 다시 설정하므로 별도 커스텀 tint는 별도 material/Variant에 보존하세요. Built-in Standard / URP Lit 대상입니다. 실제 Unity 실행·외형·physics·lightmap·게임 파괴/저장/네트워크 검증은 이번 환경에서 수행하지 않았습니다.

## Blender / geometry

`BlenderSources/BN_M6_Architecture_Library.blend`를 열면 수정된 금속 벽이 표시됩니다. 다른 모델은 Outliner로 표시합니다. vertex group에 추가 rim/bolt 이름이 있습니다.
`ComparisonScenes/BN_M6_Assembly_And_Cut_References.blend`의 `00_Catalog` 및 A~G/파괴 참고 scene에도 수정 메시를 반영했습니다. 새 렌더 이미지는 생성하지 않았습니다.

피벗·구조 두께·snap 기준·collider는 유지했습니다. 나사/테두리는 visual detail이므로 최대 visual bounds는 조금 커집니다. 예를 들어 금속 벽 구조 두께는 .15m, 양면 테두리를 포함한 visual 두께는 .174m입니다. KitManifest의 dimensions/bounds는 visual bounds이며 thickness/colliders는 구조 기준입니다. small hardware용 collider는 추가하지 않았습니다.

나사 center에서 실제 지지 메시로 raycast하여 표면 일치와 1mm seating을 검사했습니다. 테두리는 도장 면 안으로 2mm 맞물립니다. 맞댐 위치의 반대 방향 내부 접촉면은 두 개의 독립된 닫힌 부품의 정상 접촉입니다.

33개 모델의 geometry/UV/normal/FBX 및 UV1 겹침 검사를 재실행했습니다. 검사 파일은 Reports, 상세 수치는 ASSET_CATALOG.md를 참고하세요. 과거 변경 내역의 v1/v2 수치는 이 v3 수치로 대체됩니다.
'''
(o/'README_KO.md').write_text(readme,encoding='utf-8')
rows=['# v3 asset catalog','','Blender local X/Y/Z visual bounds (m). 구조 thickness/pivot/collider는 manifest 별도 항목.','','| Key | Dimensions | Quads | Tris |','|---|---|---:|---:|']
for x in m['assets']:rows.append('| '+x['key']+' | '+' × '.join(f'{v:.3f}' for v in x['dimensions'])+f" | {x['quads']} | {x['tris']} |")
(o/'ASSET_CATALOG.md').write_text('\n'.join(rows)+'\n',encoding='utf-8')
summary='''# v3 validation

- 33 FBX source/reimport geometry signature, oriented face material assignment, UV0/UV1 and corner normals compared.
- Tangent layer present in all FBX files. UV1 positive-area overlap = 0.
- 33 source meshes: no nonquad/nonmanifold/zero-area/twisted quad/invalid UV findings.
- 24 PNGs byte-identical to v2. Default tint dictionary and Unity Editor code byte/value identical to v2.
- All added bolt center seating checked against the original supporting visual mesh with BVH ray casts. Reports/Hardware_V3_Changes.json contains measured surface error and 1mm embed specification.
- Rim miter caps meet as opposite-facing closed surfaces; geometry-signature matching distinguishes these by face orientation.
- Source tests do not prove Unity rendering, compression/mip appearance, physics, lightmap or gameplay behavior. Those were not run. No new preview render was generated.
'''
(o/'Reports/VALIDATION_SUMMARY_KO.md').write_text(summary,encoding='utf-8')
cp=o/'CHANGELOG.md';cp.write_text('# v3 — metal hardware\n\n'+readme.split('## 텍스처')[0].split('## 이번 수정')[1]+'\n\n## Previous v2 notes\n\n'+cp.read_text(encoding='utf-8'),encoding='utf-8')
for name in ['qa_art_v3.py','prepare_qa_v3.py','package_art_v3.py']:shutil.copy2(r/'work'/name,o/'RebuildScripts'/name)
rp=o/'RebuildScripts/README.md';rp.write_text(rp.read_text(encoding='utf-8')+'\n## v3\nAfter v2 is present in outputs, run work/detail_art_v3.py with Blender. Then run prepare_qa_v3.py with Python, qa_art_v3.py with Blender, and package_art_v3.py with Python. These preserve v2 and create v3.\n',encoding='utf-8')
files=sorted(p for p in o.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt')
(o/'SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(o).as_posix() for p in files)+'\n')
zp=o.with_suffix('.zip')
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(o.rglob('*')):
  if p.is_file():z.write(p,o.name+'/'+p.relative_to(o).as_posix())
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
(r/'outputs'/(zp.name+'.sha256')).write_text(hashlib.sha256(zp.read_bytes()).hexdigest()+'  '+zp.name+'\n')
print('V3_DELIVERY_COMPLETE',len(changes),'models updated',round(zp.stat().st_size/1024**2,2),'MiB')
