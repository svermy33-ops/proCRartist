import bpy,numpy as np,pathlib,json,math,sys
from mathutils import Vector
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs'/'BREAK_NORTH_M6_Architecture_v1';AS=OUT/'Assets'/'BREAK_NORTH_M6_Architecture'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'BlenderSources'/'BN_M6_Architecture_Library.blend'))
manifest=json.loads((AS/'KitManifest.json').read_text())
from io_scene_fbx import parse_fbx
def nodes(el,name):
    result=[]
    if el.id==name:result.append(el)
    for c in el.elems:result.extend(nodes(c,name))
    return result

def poly_sig(ob,p):
    return tuple(sorted(tuple(round(t,5) for t in (ob.matrix_world@ob.data.vertices[v].co)) for v in p.vertices))

def triangle_intersection_area(subject,clip):
    # Convex polygon clipping; shared boundaries have zero area.
    signed=sum(clip[i][0]*clip[(i+1)%3][1]-clip[(i+1)%3][0]*clip[i][1] for i in range(3))
    if signed<0:clip=clip[::-1]
    poly=subject
    for i in range(3):
        a=np.array(clip[i]);b=np.array(clip[(i+1)%3]);edge=b-a
        def side(p):return edge[0]*(p[1]-a[1])-edge[1]*(p[0]-a[0])
        out=[]
        for j in range(len(poly)):
            p=np.array(poly[j]);q=np.array(poly[(j+1)%len(poly)]);sp=side(p);sq=side(q)
            if sp>=0:out.append(p)
            if (sp>0 and sq<0) or (sp<0 and sq>0):out.append(p+(q-p)*sp/(sp-sq))
        poly=out
        if len(poly)<3:return 0
    return abs(sum(poly[i][0]*poly[(i+1)%len(poly)][1]-poly[(i+1)%len(poly)][0]*poly[i][1] for i in range(len(poly))))*.5

qa=[]
for a in manifest['assets']:
    src=bpy.data.objects['SM_BN675_'+a['key']];me=src.data
    faces={poly_sig(src,p):p for p in me.polygons}
    triangles=[];buckets={};overlap=0
    uv=me.uv_layers[1]
    for p in me.polygons:
        coords=[tuple(uv.data[l].uv) for l in p.loop_indices]
        for ids in [(0,1,2),(0,2,3)]:
            t=[coords[i] for i in ids];idx=len(triangles);triangles.append(t)
            lo=[min(v[d] for v in t) for d in range(2)];hi=[max(v[d] for v in t) for d in range(2)]
            cells=[(u,v) for u in range(int(lo[0]*24),int(hi[0]*24)+1) for v in range(int(lo[1]*24),int(hi[1]*24)+1)]
            others=set(j for c in cells for j in buckets.get(c,[]))
            for j in others:
                if triangle_intersection_area(t,triangles[j])>1e-10:overlap+=1
            for c in cells:buckets.setdefault(c,[]).append(idx)
    assert overlap==0,(a['key'],'UV1 overlap',overlap)
    path=AS/'Models'/('SM_BN675_'+a['key']+'.fbx')
    tree,version=parse_fbx.parse(str(path));tangent_layers=len(nodes(tree,b'LayerElementTangent'))
    assert tangent_layers>=1
    bpy.ops.import_scene.fbx(filepath=str(path),use_custom_normals=True)
    imp=bpy.context.selected_objects[0];bpy.context.view_layer.update()
    uv_err=0;normal_err=0
    for p in imp.data.polygons:
        sp=faces[poly_sig(imp,p)]
        assert p.material_index==sp.material_index,(a['key'],'slot mismatch')
        src_by_vertex={tuple(round(t,5) for t in me.vertices[me.loops[l].vertex_index].co):l for l in sp.loop_indices}
        for l in p.loop_indices:
            pos=tuple(round(t,5) for t in imp.matrix_world@imp.data.vertices[imp.data.loops[l].vertex_index].co)
            sl=src_by_vertex[pos]
            for layer in range(2):uv_err=max(uv_err,(imp.data.uv_layers[layer].data[l].uv-me.uv_layers[layer].data[sl].uv).length)
            n=(imp.matrix_world.to_3x3()@imp.data.corner_normals[l].vector).normalized()
            sn=me.corner_normals[sl].vector
            normal_err=max(normal_err,(n-sn).length)
    assert uv_err<.0001 and normal_err<.001,(a['key'],uv_err,normal_err)
    qa.append(dict(key=a['key'],UV1PositiveAreaOverlaps=overlap,fbxTangentLayers=tangent_layers,materialFaceAssignmentsPreserved=True,maxUVError=uv_err,maxNormalVectorError=normal_err))
    bpy.data.objects.remove(imp,do_unlink=True)
    print('DEEP_QA_OK',a['key'],flush=True)

tex=[]
for p in sorted((AS/'Textures').glob('*.png')):
    im=bpy.data.images.load(str(p),check_existing=False);im.colorspace_settings.name='Non-Color'
    arr=np.empty(im.size[0]*im.size[1]*4,np.float32);im.pixels.foreach_get(arr);arr=arr.reshape(im.size[1],im.size[0],4)
    assert im.size[:]==(1024,1024) and np.isfinite(arr).all()
    rec=dict(file=p.name,size=[1024,1024],min=float(arr.min()),max=float(arr.max()))
    if '_Normal' in p.name:
        n=arr[:,:,:3]*2-1;length=np.linalg.norm(n,axis=2)
        rec['maxUnitLengthError']=float(abs(length-1).max());rec['minTangentZ']=float(n[:,:,2].min())
        assert rec['maxUnitLengthError']<.015 and rec['minTangentZ']>0
    # Seam delta is compared with the ordinary adjacent-texel distribution; equality is not required.
    boundary=np.concatenate([abs(arr[0,:,:3]-arr[-1,:,:3]).ravel(),abs(arr[:,0,:3]-arr[:,-1,:3]).ravel()])
    inside=np.concatenate([abs(arr[1:,:,:3]-arr[:-1,:,:3]).ravel(),abs(arr[:,1:,:3]-arr[:,:-1,:3]).ravel()])
    rec['meanBoundaryDelta']=float(boundary.mean());rec['meanInternalDelta']=float(inside.mean())
    tex.append(rec);bpy.data.images.remove(im)
(OUT/'Reports'/'Material_UV_Normal_QA.json').write_text(json.dumps(dict(models=qa,textures=tex),indent=2))
print('DEEP_QA_COMPLETE',len(qa),len(tex),flush=True)
