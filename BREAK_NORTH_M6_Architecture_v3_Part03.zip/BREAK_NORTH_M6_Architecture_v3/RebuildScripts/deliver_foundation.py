import pathlib,json,csv,hashlib,zipfile,shutil
ROOT=pathlib.Path(__file__).resolve().parents[1];OUT=ROOT/'outputs'/'BREAK_NORTH_M6_Architecture_v1';AS=OUT/'Assets'/'BREAK_NORTH_M6_Architecture'
m=json.loads((AS/'KitManifest.json').read_text());qa=json.loads((OUT/'Reports'/'Material_UV_Normal_QA.json').read_text());geo=json.loads((OUT/'Reports'/'Geometry_And_FBX_Checks.json').read_text())
def write(name,s):(OUT/name).write_text(s,encoding='utf-8')
write('README_KO.md','''# BREAK NORTH — M6 Architectural Foundation v1

2026-09-14 / Blender 5.2.1 LTS에서 제작·검사.

요청한 **필수 11종 + 권장 6종**을 제작했습니다. 벽 두께에 맞춘 형상 변형을 합쳐 **실제 모델 27개**, 조립/단면 참고용 보조 모델 6개, 총 FBX 33개입니다. 8개 재질 family의 1K BaseColor / Normal / MetallicSmoothness 텍스처 24장을 포함합니다. 색만 다른 FBX는 없습니다.

사용자의 최신 방향을 적용했습니다. 형상은 낮은 폴리곤과 작은 bevel을 유지하고, 콘크리트 기공·골재, 도장 요철·짧은 긁힘, 금속의 방향성 표면은 PBR 텍스처와 노멀맵으로 표현합니다. 중립색 BaseColor와 독립된 Face A/B 재질을 사용합니다. 거대한 오염 패턴이나 파괴 그리드는 넣지 않았습니다.

## Unity에서 사용

1. ZIP을 풀고 `Assets/BREAK_NORTH_M6_Architecture` 폴더 전체를 Unity 프로젝트의 `Assets`에 복사합니다. FBX만 복사하면 PBR 재질 연결과 충돌체 생성 도구가 빠집니다.
2. 에디터의 스크립트 컴파일 및 임포트가 끝나면 `BREAK NORTH > M6 Architecture > 1 - Build Materials and Prefabs`를 실행합니다.
3. `2 - Validate Imported Prefabs`를 실행해 크기·피벗·재질 연결·충돌체 수·루트 scale을 확인합니다. 결과는 해당 Assets 폴더의 `Validation/UnityImportReport.txt`에 저장됩니다.
4. `3 - Create Assembly and Cut Reference Scene`을 실행하면 14개 참고 배치를 가진 새 additive scene이 생성됩니다. 기존에 열린 scene은 유지합니다. Scene 뷰에서 그룹을 선택하고 F로 확인할 수 있습니다.
5. 실제 배치에는 생성된 `Prefabs`를 사용합니다. 단순 FBX 자체에는 Unity Collider가 붙어 있지 않습니다.

Built-in Standard / URP Lit 연결 코드를 제공합니다. HDRP는 별도 변환 대상입니다. 최초 임포트에서 Unity가 .meta/GUID를 생성하므로 이후에는 해당 파일을 보존하세요. 기존 M6/M7 폴더는 변경하지 않습니다. 메뉴 1 재실행은 이번 폴더의 재질 연결·프리팹을 다시 만들므로, 프리팹을 커스터마이즈할 때는 별도 Variant를 사용하세요. 기존 재질 tint 값은 재실행 시 유지됩니다.

## Blender에서 편집

- `BlenderSources/BN_M6_Architecture_Library.blend`: 원점이 유지된 편집 원본. 처음에는 콘크리트 벽만 표시되어 있습니다. 다른 모델은 Outliner의 눈 아이콘으로 표시하세요. Edit Mode의 vertex groups에서 core, flange, jamb 등 부품을 선택할 수 있습니다.
- `ComparisonScenes/BN_M6_Assembly_And_Cut_References.blend`: `00_Catalog`에서 27개 모델을 나란히 비교합니다. Scene 선택 메뉴에 A~G 조립 검사 7개와 파괴 상태 참고 7개가 있습니다.
- 두 .blend 모두 텍스처 24장이 내부에 pack되어 있습니다. 외부 파일 상대 경로도 제공됩니다.

새 미리보기 렌더 이미지는 생성하지 않았습니다.

## 제작 결과와 검증 범위

- 벽: 5m × 2.5m, 두께 0.30 / 0.15 / 0.40m. 각 108 tris.
- 슬래브: 2.5m 정사각형, 두께 0.35m. 108 tris.
- 기둥: 최대 폭 0.40 / 0.50m, 높이 2.5m. 324 tris.
- 빔: 길이 5m, 단면 폭/높이 0.40m. 324 tris.
- 문틀: 540 tris. 해치틀: 432 tris. L/T/X 연결부: 324 / 432 / 540 tris.
- 원본·FBX 모두 쿼드, 닫힌 각 부품, UV0·UV1, normals 및 tangent 데이터를 검사했습니다. UV1의 양의 면적 겹침도 검사했습니다.
- **실제 Unity가 이 작업 환경에 없어 C# 컴파일·메뉴 실행·게임 화면·physics·lightmap bake는 실행하지 않았습니다.** 제공한 Unity 검증 메뉴에서 실제 임포트 결과를 확인해야 합니다.
- 파괴 참고 장면은 정적인 모델 배치입니다. 런타임 구멍 생성, 파편, 내구도, Save/Load/Host/Late Join은 게임 코드의 검증 범위입니다. 해당 기능을 구현한 패키지가 아닙니다.

세부 내용은 `ASSET_CATALOG.md`, `MATERIAL_UV_CONTRACT.md`, `ASSEMBLY_AND_GAME_INTEGRATION.md`, `Reports`에 있습니다.
''')
write('MATERIAL_UV_CONTRACT.md','''# Material / UV contract

## Slots and independent surfaces

Wall: slot 0 FaceA (Blender -Y), 1 FaceB (+Y), 2 Interior (±X, ±Z).
Slab: slot 0 Top (+Z), 1 Bottom (-Z), 2 Interior (±X, ±Y).
Door/Hatch: slot 0 Frame, 1 Interior (opening-facing jamb/reveal faces).
WallEndCap: slot 0 Exterior, 1 Interior (-X mating face).
Column/Beam/Joints/Trims: slot 0 Structural.

각 에셋의 순서 및 family는 KitManifest.json의 materialNames / roles / families에 1:1로 기록합니다. FaceA와 FaceB는 같은 초기 family라도 서로 다른 Material 이름과 .mat를 사용합니다. Unity에서 한쪽을 PaintedMetalNeutral 계열의 재질로 교체해도 다른 면에 영향을 주지 않습니다. 색상 변형은 메시 복제가 아닌 Material tint 또는 게임의 MaterialPropertyBlock 정책으로 처리합니다. 서로 다른 roughness/metallic도 필요하면 별도 material을 사용하세요.

Surface는 비교적 밝고 미세한 기공, Interior는 더 어둡고 큰 골재를 사용합니다. ReinforcedInterior는 더 거친 골재이며 **실제 철근 geometry를 포함하지 않습니다**. 노출 철근이 필요한 파괴 상태는 게임 측 별도 구조/파편으로 처리합니다. 이 패키지는 유리·발광·투명 shader를 요구하지 않습니다.

## Texture maps

8 families: ConcreteSurfaceNeutral, ConcreteInterior, PaintedMetalNeutral, BareCutMetal, StructuralSteel, FloorNeutral, CeilingNeutral, ReinforcedInterior.

각 family는 seamless repeat용 1024² PNG 3개를 공유합니다.

| Suffix | 공간 | 사용 |
|---|---|---|
| BaseColor | sRGB | 중립색 albedo; material tint로 테마 색 지정 |
| Normal | linear / Unity NormalMap | OpenGL +Y tangent-space; 강도 기본 1.0 |
| MetallicSmoothness | linear | R=metallic, A=smoothness, G/B=0 |

Blender에서는 normal strength 1, MetallicSmoothness alpha를 1-alpha로 바꿔 roughness에 연결했습니다. Unity에서는 roughness 파일을 요구하지 않습니다. MS alpha를 투명도로 해석하지 마세요. Normal green을 임의로 반전하지 마세요. M6 v4/M7의 이전 normal strength를 이 패키지에 전역 적용하지 않습니다.

이 텍스처는 절차적으로 직접 제작한 재질이며 사진 스캔 재질이라고 주장하지 않습니다. 고주파 displacement를 실제 메시로 추가하지 않았습니다. 단면 normal은 조명 반응을 바꾸지만 단면의 실제 silhouette을 파괴 형태로 바꾸지는 않습니다.

## UV0 and runtime surface generation

Blender `UV0_Material` = Unity UV channel 0. `UV1_Lightmap` = Unity UV channel 1 (Mesh.uv2).
UV0는 atlas가 아닌 타일 좌표입니다. 전 family가 **2m / UV 1주기**입니다. Default material tiling (1,1), offset (0,0). 5m 벽에는 2.5주기, 2.5m 높이에는 1.25주기가 들어갑니다. 기둥/트림도 같은 물리 밀도를 사용합니다.

Blender local position (x,y,z), dominant face normal axis 및 부호 s 기준:

| 면 | U | V |
|---|---|---|
| ±X | s*y/2 | z/2 |
| ±Y | -s*x/2 | z/2 |
| ±Z | x/2 | s*y/2 |

곡면 bevel 면은 기하학적 face normal의 최대 절댓값 축을 사용합니다. 축이 바뀌는 곳에는 UV split이 있습니다. Mikk tangents를 재계산하세요. UV0를 [0,1] 안으로 임의 정규화하거나 세그먼트마다 다시 투영하면 물리 밀도/연속성이 달라집니다.

납품 모델/참고 장면은 모듈별 local UV입니다. 게임에서 긴 연속 표면을 생성할 때는 경계에 공통된 **boundary-space position**을 위 식에 넣고, 동일 boundary origin·rotation·UV phase를 모든 세그먼트와 Save/Load에 유지하세요. 이 패키지의 FBX를 transform scale로 늘리면 UV 물리 밀도도 늘어납니다. 길이가 다른 runtime segment는 vertex position에서 UV를 다시 계산하는 것이 기본입니다. World UV 적용 코드 자체는 본 패키지에 포함하지 않았습니다.

앞/뒷면 UV는 각각 right-handed tangent frame이므로 뒤쪽에서는 U가 반대입니다. 반대쪽 텍스처를 억지로 동일 좌표로 복사하지 마세요. Runtime 새 cut face는 Interior slot을 사용하고 위치/normal로 UV를 만든 뒤 normal/tangent를 갱신해야 합니다.

UV1은 별도 smart-project packing이며 양의 면적 island overlap은 검사했습니다. 작은 bevel face는 낮은 lightmap 해상도에서 subpixel이 될 수 있습니다. island padding과 실제 bake 품질은 프로젝트 lightmap 해상도에서 확인해야 합니다. Importer는 제공 UV1을 유지하며 자동 재생성을 끕니다.

FBX는 -Z Forward / Y Up, metre 단위를 사용합니다. Blender reimport에서 축 보정 rotation이 보일 수 있으므로 object.dimensions만이 아닌 world-space bounds/vertices로 비교했습니다. 실제 Unity 루트 scale과 bounds는 제공 검증 메뉴가 검사합니다.
''')
write('ASSEMBLY_AND_GAME_INTEGRATION.md','''# Assembly and game integration

## Module rules

모든 치수는 metre. Blender +Z up, 기본 벽 정면 -Y. Unity builder는 위치를 (x,z,-y), 크기를 (x,z,y)로 변환합니다. Source transform은 identity입니다. Unity prefabs의 루트 transform은 identity로 생성합니다.

- Wall: bottom-center, X=-2.5..2.5, Z=0..2.5.
- Slab: top-center, X/Y=-1.25..1.25, Z=-0.35..0.
- Columns: bottom-center, 높이 2.5. A 최대 폭 .40, B .50. Base/head collars 내부로 core가 들어갑니다.
- Beam: 왼쪽 연결 끝의 단면 중앙, X=0..5, Y/Z=-.20...20. 기둥 사이 clear span 5m용이며 기둥 중심 사이 길이와 다릅니다.
- Joint: bottom-center. Concrete/Metal/Reinforced의 최외곽 연결면은 각각 ±.17 / ±.095 / ±.22m. 연결 방향은 Corner=+X,+Y, T=±X,+Y, X=±X,±Y. 게임 배치에서 적절히 회전하세요.
- EndCap: 길이 .045m의 마감. -X면을 벽 끝에 맞추면 pivot은 벽 끝에서 +.0225m입니다. 반대쪽 끝에는 180° 회전합니다. .30/.15/.40 벽 두께 변형을 각각 사용하세요.
- Door: frame-base center. 외곽 폭 1.44m, 높이 2.35m. 실개구부 1.20×2.23m. 깊이는 벽보다 .06m 큽니다. 5m 벽을 그대로 뒤에 겹치지 말고 벽 자체에 개구부를 생성해야 합니다.
- Hatch: slab-top / opening center. 외곽 1.5m square, 개구부 1.2m square. slab 위/아래로 .02m lip. Slab에도 외곽 프레임이 들어갈 1.5m opening을 생성합니다.
- SlabEdgeTrim: X=0..2.5, edge Y=0, slab top Z=0. +Y 쪽으로 top return이 들어갑니다.
- Wall trims: local -Y 쪽으로 돌출. mounting면 기준 약 2~4mm seating이 있습니다. Horizontal은 벽·천장 만나는 선에서 X방향 2.5m.

## Joint placement

벽-벽을 겹치지 않고, wall end를 joint의 실제 연결면에서 끝냅니다. 예: Concrete Corner가 (0,0,0)이면 +X벽 중심은 (2.67,0,0), +Y벽 중심은 (0,2.67,0), Z rotation=90°. 반경 .17 + 벽 반길이 2.5입니다. 두께 변형을 바꾸면 radius도 바꿉니다.

A_Straight: 기둥 중심 ±2.70, 벽 중심 0. 기둥 core는 collar보다 좁아 접합부에 최대 12.5mm recessed seam이 있습니다. 이를 오류를 가리기 위한 벽-벽 관통으로 처리하지 않았습니다. 부품의 작은 bevel은 조립 모서리에 약한 seam을 남깁니다.

Joint의 flange는 core 안쪽에 12mm 들어갑니다. Column core와 base/head collar는 겹쳐 고정됩니다. Beam web/flange는 z=±.15에서 접촉합니다. 이 관계는 생성 치수 및 각 부품의 닫힌 topology로 확인했습니다. 모든 부품을 대상으로 삼각형-삼각형 충돌 검사를 수행한 것은 아닙니다.

Joint / Column / Beam은 Wall과 별도 mesh 및 prefab입니다. 파괴 코드는 wall collider/visual만 교체하고 skeleton은 별도로 유지해야 합니다. Cell 경계라는 이유만으로 배치하지 말고 실제 건축 교차부에만 배치합니다.

## Collision

Unity 메뉴가 manifest의 부품별 center/size를 BoxCollider로 생성합니다. collider는 bevel을 포함하지 않는 보수적인 상자 근사입니다. Visual MeshCollider를 자동으로 붙이지 않습니다. 문틀은 jamb/lintel/foot 각각의 box, 해치틀은 네 변의 box라 개구부가 열려 있습니다. Joint와 column collar에는 겹치는 box가 있지만 물리 동작은 실제 프로젝트에서 확인해야 합니다.

Wall/Slab 프리팹의 intact BoxCollider는 **정상 상태 참고용**입니다. 파괴 시 기존 box를 유지하면 구멍을 막으므로 게임의 generated collider로 교체해야 합니다. 동적 Rigidbody/내구도/레이어는 자동 추가하지 않습니다.

## Reference scenes and runtime responsibility

A~G = Straight, Corner, T, X, Slab structure, Door opening, Hatch opening.
파괴 참고 7개 = wall center, wall edge, corner one side, corner both sides, T 주변, floor hole, ceiling hole.

참고용 broken wall은 직사각형 구멍 주변을 closed pieces로 배치했습니다. FBX에 파괴 cell을 미리 새긴 것이 아니며 runtime fracture 예제 코드도 아닙니다. Fixture_* 6개는 이 참고 배치용이며 실제 에셋 27개 수에 포함하지 않습니다. 일부 연결부의 빈 부분은 파괴로 제거된 영역을 뜻합니다.

Save → Load → Host → Late Join 일치 여부는 개발 프로젝트에서 다음 정보를 같은 규칙으로 직렬화·재생성하여 검사합니다: boundary ID, origin/rotation/dimensions/thickness, face A/B/interior material role, UV phase, opening polygon/cut state, joint type/variant/transform. 모델 파일만으로 이 동작을 보장할 수 없습니다.

프로젝트 수용 검사: 양면 서로 다른 재질 / 3가지 벽 두께 / 연결부 인접 파괴 / 문·해치 통과 / top-bottom 역전 없음 / 파괴 collider 교체 / loaded geometry 동일성 / tangent/normal seam / 실내 조명과 mip/UV1 bake.
''')
rows=['# Asset catalog','', '실제 에셋 27개 = 17종 요구사항 + 두께별 형상 변형. 크기는 Blender local X/Y/Z metre. Tris는 runtime 환산.', '', '| Key | X × Y × Z (m) | Quads | Tris | Slots |','|---|---|---:|---:|---|']
for a in m['assets']:
    if a['fixture']:continue
    rows.append('| '+a['key']+' | '+' × '.join(f'{v:.3f}' for v in a['dimensions'])+f" | {a['quads']} | {a['tris']} | "+' / '.join(a['roles'])+' |')
rows+=['','모든 실제 모델은 해당 요청의 목표 상한 이내입니다. WallEndCap/BeamEndCap에는 요청서상 별도 최소치가 없어 108 tris로 제작했습니다. 동일 소재·색상 변형용 FBX는 생성하지 않았습니다.','','## Test fixtures','']
rows += ['- '+a['key']+' (108 tris)' for a in m['assets'] if a['fixture']]
write('ASSET_CATALOG.md','\n'.join(rows)+'\n')
maxv=max(a['fbx']['maxWorldVertexErrorMetres'] for a in geo)
maxn=max(a['maxNormalVectorError'] for a in qa['models'])
write('Reports/VALIDATION_SUMMARY_KO.md',f'''# 검증 결과

- Blender 5.2.1 LTS 실제 실행. 원본 33개 / FBX export·reimport 33개 통과.
- non-quad, non-manifold edge, zero-area face, 뒤집힌 두 삼각형으로 구성되는 quad: 0.
- UV0/UV1 비유한 값 및 0면적 face: 0. UV1 triangle clipping 기준 양의 면적 겹침: 0.
- FBX 재가져오기: 치수·원점·vertices·면별 material index·UV0/UV1·corner normals 보존 확인.
- 최대 world vertex 오차: {maxv:.9g}m. 최대 corner normal vector 차이: {maxn:.9g}.
- FBX binary의 tangent layer 존재 확인. Unity에서는 Mikk 재계산 설정을 제공합니다.
- 텍스처 24장 전부 1024²·유한 데이터. Normal 단위벡터 오차 <.015, tangent Z >0.
- 양쪽 Blender 파일에서 packed image 24장 및 pixel data 접근 확인.
- BaseColor ConcreteInterior 텍스처 직접 열어 표면 패턴 확인. **모델 렌더 외형 검사는 하지 않았습니다.**
- 폴리곤별 world geometry signature로 UV·재질·normal을 대조했습니다. 단순 개수만 비교하지 않았습니다.

절차적 texture는 periodic sampling으로 제작했습니다. seam 통계는 Material_UV_Normal_QA.json에 기록했으며, Unity의 압축/mip 상태에서 seam이 없다고 확정한 검사는 아닙니다.

Blender가 사용자 AppData cache/thumbnail 경로 쓰기 경고를 냈으나, 작업 폴더의 PNG/FBX/.blend 저장 및 재열기·검사 완료를 따로 확인했습니다. 이 경고를 에셋 저장 성공/실패의 단독 근거로 삼지 않았습니다.

미실행: Unity C# compile/menu, 실게임 화면 및 art approval, physics, baked lightmap, runtime fracture, Save/Load/Host/Late Join. 본문 및 README에 동일하게 명시했습니다.
''')
srcdir=OUT/'RebuildScripts';srcdir.mkdir(exist_ok=True)
for name in ['build_foundation.py','qa_foundation.py','finalize_sources.py','deliver_foundation.py']:
    shutil.copy2(ROOT/'work'/name,srcdir/name)
write('RebuildScripts/README.md','''# Rebuild

Dependencies: Blender 5.2.1 (bpy, bmesh, bundled numpy). No downloaded texture assets.

To reproduce the delivered workspace layout, create a working folder with a `work` subfolder, copy the Python files into `work`, and copy the delivered `Assets` folder into `outputs/BREAK_NORTH_M6_Architecture_v1/Assets` so the Unity Editor source is preserved. Run from that working folder:

```
blender -b -t 4 --python-exit-code 1 --python work/build_foundation.py
blender -b -t 4 --python-exit-code 1 --python work/qa_foundation.py
blender -b -t 2 --python-exit-code 1 --python work/finalize_sources.py
python work/deliver_foundation.py
```

The scripts derive their working root from their parent directory. Output is created under that root's `outputs/BREAK_NORTH_M6_Architecture_v1`. Run in a scratch copy to preserve delivered files. Success markers are BUILD_FOUNDATION_COMPLETE, DEEP_QA_COMPLETE, SOURCE_PACK_OK and DELIVERY_COMPLETE. The final packaging script needs only Python standard library. No preview render is generated.
''')

# Move only exact generated Blender backup files into a verified workspace archive.
archive=ROOT/'work'/'archive'/'foundation_backups';archive.mkdir(parents=True,exist_ok=True)
for p in OUT.rglob('*.blend1'):
    assert p.resolve().is_relative_to(OUT.resolve())
    dest=archive/p.name
    if dest.exists():dest=archive/(p.stem+'_'+str(p.stat().st_mtime_ns)+'.blend1')
    shutil.move(str(p),str(dest))
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt')
write('SHA256SUMS.txt','\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(OUT).as_posix() for p in files)+'\n')
zip_path=OUT.with_suffix('.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():z.write(p,OUT.name+'/'+p.relative_to(OUT).as_posix())
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    names=z.namelist();assert len([n for n in names if n.endswith('.fbx')])==33
    assert len([n for n in names if n.endswith('.png')])==24
    assert len([n for n in names if n.endswith('.blend')])==2
    assert len(names)==len(set(names))
(zip_path.parent/(zip_path.name+'.sha256')).write_text(hashlib.sha256(zip_path.read_bytes()).hexdigest()+'  '+zip_path.name+'\n')
print('DELIVERY_COMPLETE',len(names),'files',round(zip_path.stat().st_size/1024**2,2),'MiB',flush=True)
