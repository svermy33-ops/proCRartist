import bpy,numpy as np,pathlib,shutil,json,math,hashlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1];old=ROOT/'outputs/BREAK_NORTH_M6_Architecture_v1';out=ROOT/'outputs/BREAK_NORTH_M6_Architecture_v2'
shutil.copytree(old,out,dirs_exist_ok=True)
assets=out/'Assets/BREAK_NORTH_M6_Architecture';tex=assets/'Textures'
palette={'ConcreteSurfaceNeutral':'E4D9C3','ConcreteInterior':'C5BBA5','PaintedMetalNeutral':'B5C8D8','BareCutMetal':'CBD4DC','StructuralSteel':'AABECE','FloorNeutral':'C6C9C5','CeilingNeutral':'EBE5D6','ReinforcedInterior':'B8B3A5'}
def linear(v):return v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4
def rgb(h):return [int(h[i:i+2],16)/255 for i in (0,2,4)]
def load(path):
 im=bpy.data.images.load(str(path),check_existing=False);im.colorspace_settings.name='Non-Color';a=np.empty(1024*1024*4,np.float32);im.pixels.foreach_get(a);bpy.data.images.remove(im);return a.reshape(1024,1024,4)
def save(path,a,data=True):
 im=bpy.data.images.new(path.stem,1024,1024,alpha=True);im.colorspace_settings.name='Non-Color' if data else 'sRGB';im.pixels.foreach_set(a.astype(np.float32).ravel());im.filepath_raw=str(path);im.file_format='PNG';im.save();bpy.data.images.remove(im)
y,x=np.mgrid[0:1024,0:1024]/1024
# Smooth periodic directional waves have no interpolated random square-cell grid.
field=sum(np.sin(2*math.pi*(u*x+v*y)+phase)*weight for u,v,phase,weight in [(3,7,.4,.28),(11,-5,1.8,.24),(7,13,2.6,.2),(17,9,.7,.16),(23,-11,4.2,.12)])
metrics=[]
for family in palette:
 bc=load(tex/(family+'_BaseColor.png'));before=bc[:,:,:3].copy();v=bc[:,:,0];mean=float(v.mean())
 target={'ConcreteSurfaceNeutral':.91,'ConcreteInterior':.77,'PaintedMetalNeutral':.92,'BareCutMetal':.86,'StructuralSteel':.86,'FloorNeutral':.88,'CeilingNeutral':.94,'ReinforcedInterior':.74}[family]
 bc[:,:,:3]=np.clip(target+(v-mean)[:,:,None]*(.70 if 'Interior' in family else .8),0,1)
 ms=load(tex/(family+'_MetallicSmoothness.png'))
 old_std=float(ms[:,:,3].std())
 if family in ['StructuralSteel','BareCutMetal']:
  rough=.56 if family=='StructuralSteel' else .48
  ms[:,:,0]=.72 if family=='StructuralSteel' else .9
  ms[:,:,3]=1-rough-field*.014
  # Preserve a fine brushed response without pixel-scale alternating bands.
  height=np.sin(2*math.pi*(3*x+91*y))*.000015+np.sin(2*math.pi*(-5*x+137*y)+.8)*.000009+field*.00001
  du=(np.roll(height,-1,1)-np.roll(height,1,1))/(4/1024);dv=(np.roll(height,-1,0)-np.roll(height,1,0))/(4/1024)
  n=np.stack([-du,-dv,np.ones_like(du)],2);n/=np.linalg.norm(n,axis=2)[:,:,None]
  normal=np.ones_like(ms);normal[:,:,:3]=n*.5+.5;save(tex/(family+'_Normal.png'),normal)
  bc[:,:,:3]=target+field[:,:,None]*.009
 elif family=='PaintedMetalNeutral':
  ms[:,:,3]=.46-field*.01
 save(tex/(family+'_BaseColor.png'),bc,False);save(tex/(family+'_MetallicSmoothness.png'),ms)
 metrics.append(dict(family=family,oldMeanBase=float(before.mean()),newMeanBase=float(bc[:,:,:3].mean()),oldSmoothnessStd=old_std,newSmoothnessStd=float(ms[:,:,3].std()),tint='#'+palette[family]))

for folder,name in [('BlenderSources','BN_M6_Architecture_Library.blend'),('ComparisonScenes','BN_M6_Assembly_And_Cut_References.blend')]:
 bpy.ops.wm.open_mainfile(filepath=str(out/folder/name));bpy.context.preferences.filepaths.save_version=0
 images={}
 for im in list(bpy.data.images):
  replacement=bpy.data.images.load(str(tex/(im.name+'.png')),check_existing=False)
  replacement.colorspace_settings.name='sRGB' if im.name.endswith('BaseColor') else 'Non-Color'
  for mat in bpy.data.materials:
   if mat.use_nodes:
    for node in mat.node_tree.nodes:
     if node.type=='TEX_IMAGE' and node.image==im:node.image=replacement
  original=im.name;bpy.data.images.remove(im);replacement.name=original;replacement.pack();replacement.filepath='//../Assets/BREAK_NORTH_M6_Architecture/Textures/'+original+'.png'
 for mat in bpy.data.materials:
  family=mat.get('family')
  if family not in palette:continue
  nt=mat.node_tree;bs=nt.nodes.get('Principled BSDF');bc=next(n for n in nt.nodes if n.type=='TEX_IMAGE' and n.image.name.endswith('BaseColor'))
  mul=nt.nodes.new('ShaderNodeMixRGB');mul.name='Handoff_Default_Tint';mul.blend_type='MULTIPLY';mul.inputs[0].default_value=1
  tint=[linear(v) for v in rgb(palette[family])]+[1]
  mul.inputs[2].default_value=tint;nt.links.new(bc.outputs['Color'],mul.inputs[1]);nt.links.new(mul.outputs[0],bs.inputs['Base Color']);mat.diffuse_color=tint
 bpy.ops.wm.save_as_mainfile(filepath=str(out/folder/name))

cs=assets/'Editor/BN675ArchitectureImporter.cs';code=cs.read_text(encoding='utf-8')
mapping='\n'.join('                case "'+fam+'": hex="#'+h+'"; break;' for fam,h in palette.items())
helper='''        static Color DefaultTint(string family) {
            string hex="#FFFFFF";
            switch(family) {
MAPPING
            }
            ColorUtility.TryParseHtmlString(hex,out var color); return color;
        }
'''.replace('MAPPING',mapping)
code=code.replace('        static Material MakeMaterial(',helper+'        static Material MakeMaterial(')
code=code.replace('if(create)m.SetColor(urp?"_BaseColor":"_Color",Color.white);','m.SetColor(urp?"_BaseColor":"_Color",DefaultTint(family));')
code=code.replace('// Neutral tint. Face A and B are separate Material assets and may be tinted independently.','// v2 handoff palette; Build reapplies defaults. Face A/B remain independent.')
cs.write_text(code,encoding='utf-8')
manifest=json.loads((assets/'KitManifest.json').read_text());manifest['version']='M6_Architecture_v2';manifest['defaultTintSRGB']=palette
(assets/'KitManifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(out/'Reports/Art_Revision_Metrics.json').write_text(json.dumps(metrics,indent=2))
readme=out/'README_KO.md';s=readme.read_text(encoding='utf-8');s=s.replace('Foundation v1','Foundation v2').replace('기존 재질 tint 값은 재실행 시 유지됩니다.','v2의 메뉴 1은 이번 패키지의 기본 handoff 팔레트를 다시 적용합니다. 커스텀 색은 별도 재질/Variant로 보존하세요.')
s=s.replace('중립색 BaseColor와 독립된 Face A/B 재질을 사용합니다.','밝은 중립 BaseColor에 베이지 콘크리트·청회색 금속의 기본 tint를 곱합니다. Face A/B는 독립되어 있습니다.')
s+='\n## v2 색감·금속 수정\n\n금속 roughness의 사각 셀 노이즈를 연속적인 저대비 패턴으로 교체했습니다. 강철은 metallic .72 / roughness 약 .56, 절단면은 .90 / 약 .48로 구분합니다. 금속 normal의 픽셀 단위에 가까운 진동도 낮췄습니다. 콘크리트 기공·골재와 도장 디테일은 유지하며, 기본 색은 밝은 베이지·청회색으로 적용했습니다. 메시·UV·폴리곤 수는 v1과 동일합니다.\n\n기존 Unity 프로젝트에서는 Assets 폴더를 같은 경로에 덮어 복사하되 .meta를 보존하고 메뉴 1을 다시 실행하세요. 기존 .mat가 흰색 tint를 계속 사용하지 않도록 v2 메뉴가 기본 팔레트를 명시적으로 적용합니다.\n'
readme.write_text(s,encoding='utf-8')
contract=out/'MATERIAL_UV_CONTRACT.md';s=contract.read_text(encoding='utf-8');s+='\n## v2 기본 팔레트\n\n중립 텍스처는 계속 공유하며 Blender multiply node / Unity material color에 동일한 sRGB 팔레트를 적용합니다. 아래 색은 최종 lit pixel 값이 아닌 tint 값입니다.\n\n'+ '\n'.join('- '+f+': #'+c for f,c in palette.items())+'\n\n금속 metallic/roughness와 base brightness는 Reports/Art_Revision_Metrics.json을 참고하세요. UV와 normal convention은 변경하지 않았습니다.\n';contract.write_text(s,encoding='utf-8')
(out/'CHANGELOG.md').write_text('''# v2 — handoff art correction

- 금속 roughness의 44×44 보간 random cell 패턴 제거. 일정한 roughness에 낮은 진폭의 연속 파형을 사용.
- Structural steel metallic .96 → .72, 평균 roughness 약 .34 → .56. Cut metal .90 / .48로 별도 유지.
- 금속 normal의 360/191-cycle 줄무늬와 pixel-scale noise를 더 안정적인 91/137-cycle brushing으로 교체.
- 모든 BaseColor 평균을 밝게 조정. 콘크리트 골재/기공·도장 scratch normal 유지.
- 베이지 콘크리트 / 청회색 금속 / 밝은 중성 바닥과 따뜻한 천장의 기본 tint를 Blender·Unity에 적용.
- FBX geometry, UV, 슬롯, pivot, collider, tris 변경 없음.
- 사용자 화면의 정확한 모자이크 현상을 직접 관찰한 것은 아님. 소스에서 확인된 사각 roughness 패턴과 강한 금속 반사를 수정했음. Unity 조명·압축·mip에 따른 외형 검증은 남아 있음.
''',encoding='utf-8')
shutil.copy2(__file__,out/'RebuildScripts/revise_art_v2.py')
print('ART_REVISION_COMPLETE',flush=True)
