# v3 validation

- 33 FBX source/reimport geometry signature, oriented face material assignment, UV0/UV1 and corner normals compared.
- Tangent layer present in all FBX files. UV1 positive-area overlap = 0.
- 33 source meshes: no nonquad/nonmanifold/zero-area/twisted quad/invalid UV findings.
- 24 PNGs byte-identical to v2. Default tint dictionary and Unity Editor code byte/value identical to v2.
- All added bolt center seating checked against the original supporting visual mesh with BVH ray casts. Reports/Hardware_V3_Changes.json contains measured surface error and 1mm embed specification.
- Rim miter caps meet as opposite-facing closed surfaces; geometry-signature matching distinguishes these by face orientation.
- Source tests do not prove Unity rendering, compression/mip appearance, physics, lightmap or gameplay behavior. Those were not run. No new preview render was generated.
