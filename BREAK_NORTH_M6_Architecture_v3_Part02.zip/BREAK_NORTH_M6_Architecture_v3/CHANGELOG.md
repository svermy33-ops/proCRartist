# v3 — metal hardware



금속 벽 양면에 얇은 45° 맞댐 테두리와 모서리 육각 체결부를 추가했습니다. 기둥 collar, 빔 flange, 금속 joint, 문틀/해치틀, end cap, reinforcement trim에도 기능적인 볼트를 추가했습니다. 콘크리트 표면에는 볼트를 추가하지 않았습니다. Concrete/Reinforced 이름의 joint/frame도 재질은 강철이므로 체결부 대상에 포함합니다.

- 금속 벽 108 → 460 tris. 양면 테두리 각 4개 및 체결부 각 4개.
- 기둥·빔 324 → 452 tris, 문틀 540 → 668 tris, 해치틀 432 → 560 tris.
- X joint 540 → 668 tris. 모든 항목은 기존 목표 상한 이내.
- 기본 모델 27개 + 참고용 6개는 유지. 그중 금속 부품이 있는 24개 수정.
- **v2 텍스처 24장 및 기본 tint 팔레트는 바이트/값 동일성을 확인했습니다.** 기존 표면의 색·질감 설정을 변경하지 않았습니다.

테두리는 기존 Face A/B의 도장 재질을 사용합니다. 금속 벽 나사는 기존 Interior의 BareCutMetal, 문틀/해치 나사는 기존 bare metal slot을 공유합니다. 다른 강철 체결부는 기존 Structural slot을 공유합니다. 추가 재질 슬롯이나 draw call은 만들지 않았습니다. 체결부는 작은 bevel이 있는 닫힌 육각 머리이며 나사산·십자 홈은 모델링하지 않았습니다.



## Previous v2 notes

# v2 — handoff art correction

- 금속 roughness의 44×44 보간 random cell 패턴 제거. 일정한 roughness에 낮은 진폭의 연속 파형을 사용.
- Structural steel metallic .96 → .72, 평균 roughness 약 .34 → .56. Cut metal .90 / .48로 별도 유지.
- 금속 normal의 360/191-cycle 줄무늬와 pixel-scale noise를 더 안정적인 91/137-cycle brushing으로 교체.
- 모든 BaseColor 평균을 밝게 조정. 콘크리트 골재/기공·도장 scratch normal 유지.
- 베이지 콘크리트 / 청회색 금속 / 밝은 중성 바닥과 따뜻한 천장의 기본 tint를 Blender·Unity에 적용.
- FBX geometry, UV, 슬롯, pivot, collider, tris 변경 없음.
- 사용자 화면의 정확한 모자이크 현상을 직접 관찰한 것은 아님. 소스에서 확인된 사각 roughness 패턴과 강한 금속 반사를 수정했음. Unity 조명·압축·mip에 따른 외형 검증은 남아 있음.
