# Assembly and game integration

## Module rules

모든 치수는 metre. Blender +Z up, 기본 벽 정면 -Y. Unity builder는 위치를 (x,z,-y), 크기를 (x,z,y)로 변환합니다. Source transform은 identity입니다. Unity prefabs의 루트 transform은 identity로 생성합니다.

- Wall: bottom-center, X=-2.5..2.5, Z=0..2.5.
- Slab: top-center, X/Y=-1.25..1.25, Z=-0.35..0.
- Columns: bottom-center, 높이 2.5. A 최대 폭 .40, B .50. Base/head collars 내부로 core가 들어갑니다.
- Beam: 왼쪽 연결 끝의 단면 중앙, X=0..5, Y/Z=-.20...20. 기둥 사이 clear span 5m용이며 기둥 중심 사이 길이와 다릅니다.
- Joint: bottom-center. Concrete/Metal/Reinforced의 최외곽 연결면은 각각 ±.17 / ±.095 / ±.22m. 연결 방향은 Corner=+X,+Y, T=±X,+Y, X=±X,±Y. 게임 배치에서 적절히 회전하세요.
- EndCap: 길이 .045m의 마감. -X면을 벽 끝에 맞추면 pivot은 벽 끝에서 +.0225m입니다. 반대쪽 끝에는 180° 회전합니다. .30/.15/.40 벽 두께 변형을 각각 사용하세요.
- Door: frame-base center. 외곽 폭 1.44m, 높이 2.35m. 실개구부 1.20×2.23m. 깊이는 벽보다 .06m 큽니다. 5m 벽을 그대로 뒤에 겹치지 말고 벽 자체에 개구부를 생성해야 합니다.
- Hatch: slab-top / opening center. 외곽 1.5m square, 개구부 1.2m square. slab 위/아래로 .02m lip. Slab에도 외곽 프레임이 들어갈 1.5m opening을 생성합니다.
- SlabEdgeTrim: X=0..2.5, edge Y=0, slab top Z=0. +Y 쪽으로 top return이 들어갑니다.
- Wall trims: local -Y 쪽으로 돌출. mounting면 기준 약 2~4mm seating이 있습니다. Horizontal은 벽·천장 만나는 선에서 X방향 2.5m.

## Joint placement

벽-벽을 겹치지 않고, wall end를 joint의 실제 연결면에서 끝냅니다. 예: Concrete Corner가 (0,0,0)이면 +X벽 중심은 (2.67,0,0), +Y벽 중심은 (0,2.67,0), Z rotation=90°. 반경 .17 + 벽 반길이 2.5입니다. 두께 변형을 바꾸면 radius도 바꿉니다.

A_Straight: 기둥 중심 ±2.70, 벽 중심 0. 기둥 core는 collar보다 좁아 접합부에 최대 12.5mm recessed seam이 있습니다. 이를 오류를 가리기 위한 벽-벽 관통으로 처리하지 않았습니다. 부품의 작은 bevel은 조립 모서리에 약한 seam을 남깁니다.

Joint의 flange는 core 안쪽에 12mm 들어갑니다. Column core와 base/head collar는 겹쳐 고정됩니다. Beam web/flange는 z=±.15에서 접촉합니다. 이 관계는 생성 치수 및 각 부품의 닫힌 topology로 확인했습니다. 모든 부품을 대상으로 삼각형-삼각형 충돌 검사를 수행한 것은 아닙니다.

Joint / Column / Beam은 Wall과 별도 mesh 및 prefab입니다. 파괴 코드는 wall collider/visual만 교체하고 skeleton은 별도로 유지해야 합니다. Cell 경계라는 이유만으로 배치하지 말고 실제 건축 교차부에만 배치합니다.

## Collision

Unity 메뉴가 manifest의 부품별 center/size를 BoxCollider로 생성합니다. collider는 bevel을 포함하지 않는 보수적인 상자 근사입니다. Visual MeshCollider를 자동으로 붙이지 않습니다. 문틀은 jamb/lintel/foot 각각의 box, 해치틀은 네 변의 box라 개구부가 열려 있습니다. Joint와 column collar에는 겹치는 box가 있지만 물리 동작은 실제 프로젝트에서 확인해야 합니다.

Wall/Slab 프리팹의 intact BoxCollider는 **정상 상태 참고용**입니다. 파괴 시 기존 box를 유지하면 구멍을 막으므로 게임의 generated collider로 교체해야 합니다. 동적 Rigidbody/내구도/레이어는 자동 추가하지 않습니다.

## Reference scenes and runtime responsibility

A~G = Straight, Corner, T, X, Slab structure, Door opening, Hatch opening.
파괴 참고 7개 = wall center, wall edge, corner one side, corner both sides, T 주변, floor hole, ceiling hole.

참고용 broken wall은 직사각형 구멍 주변을 closed pieces로 배치했습니다. FBX에 파괴 cell을 미리 새긴 것이 아니며 runtime fracture 예제 코드도 아닙니다. Fixture_* 6개는 이 참고 배치용이며 실제 에셋 27개 수에 포함하지 않습니다. 일부 연결부의 빈 부분은 파괴로 제거된 영역을 뜻합니다.

Save → Load → Host → Late Join 일치 여부는 개발 프로젝트에서 다음 정보를 같은 규칙으로 직렬화·재생성하여 검사합니다: boundary ID, origin/rotation/dimensions/thickness, face A/B/interior material role, UV phase, opening polygon/cut state, joint type/variant/transform. 모델 파일만으로 이 동작을 보장할 수 없습니다.

프로젝트 수용 검사: 양면 서로 다른 재질 / 3가지 벽 두께 / 연결부 인접 파괴 / 문·해치 통과 / top-bottom 역전 없음 / 파괴 collider 교체 / loaded geometry 동일성 / tangent/normal seam / 실내 조명과 mip/UV1 bake.
