# v3 asset catalog

Blender local X/Y/Z visual bounds (m). 구조 thickness/pivot/collider는 manifest 별도 항목.

| Key | Dimensions | Quads | Tris |
|---|---|---:|---:|
| ConcreteWallThick | 5.000 × 0.300 × 2.500 | 54 | 108 |
| MetalWallThick | 5.000 × 0.174 × 2.500 | 230 | 460 |
| ReinforcedWallThick | 5.000 × 0.400 × 2.500 | 54 | 108 |
| FloorCeilingSlab | 2.500 × 2.500 × 0.350 | 54 | 108 |
| StructuralColumnA | 0.400 × 0.408 × 2.500 | 226 | 452 |
| HeavyColumnB | 0.500 × 0.508 × 2.500 | 226 | 452 |
| HorizontalBeamA | 5.000 × 0.408 × 0.400 | 226 | 452 |
| CornerJointPost_Concrete | 0.334 × 0.342 × 2.500 | 226 | 452 |
| TJunctionPost_Concrete | 0.340 × 0.342 × 2.500 | 280 | 560 |
| XJunctionPost_Concrete | 0.340 × 0.348 × 2.500 | 334 | 668 |
| WallEndCap_Concrete | 0.053 × 0.300 × 2.500 | 86 | 172 |
| DoorFrameThick_Concrete | 1.445 × 0.374 × 2.350 | 334 | 668 |
| CornerJointPost_Metal | 0.184 × 0.192 × 2.500 | 226 | 452 |
| TJunctionPost_Metal | 0.190 × 0.192 × 2.500 | 280 | 560 |
| XJunctionPost_Metal | 0.190 × 0.198 × 2.500 | 334 | 668 |
| WallEndCap_Metal | 0.053 × 0.150 × 2.500 | 86 | 172 |
| DoorFrameThick_Metal | 1.445 × 0.224 × 2.350 | 334 | 668 |
| CornerJointPost_Reinforced | 0.434 × 0.442 × 2.500 | 226 | 452 |
| TJunctionPost_Reinforced | 0.440 × 0.442 × 2.500 | 280 | 560 |
| XJunctionPost_Reinforced | 0.440 × 0.448 × 2.500 | 334 | 668 |
| WallEndCap_Reinforced | 0.053 × 0.400 × 2.500 | 86 | 172 |
| DoorFrameThick_Reinforced | 1.445 × 0.474 × 2.350 | 334 | 668 |
| HatchFrameThick | 1.500 × 1.500 × 0.398 | 280 | 560 |
| SlabEdgeTrim | 2.500 × 0.141 × 0.365 | 140 | 280 |
| VerticalReinforcementTrim | 0.225 × 0.057 × 2.500 | 194 | 388 |
| HorizontalReinforcementTrim | 2.500 × 0.132 × 0.162 | 140 | 280 |
| BeamEndCap | 0.033 × 0.420 × 0.420 | 118 | 236 |
| Fixture_DoorLintel | 1.440 × 0.300 × 0.150 | 54 | 108 |
| Fixture_WallSide | 1.750 × 0.300 × 2.500 | 54 | 108 |
| Fixture_WallTop | 1.500 × 0.300 × 0.650 | 54 | 108 |
| Fixture_WallBottom | 1.500 × 0.300 × 0.550 | 54 | 108 |
| Fixture_SlabSide | 0.500 × 2.500 × 0.350 | 54 | 108 |
| Fixture_SlabEnd | 1.500 × 0.500 × 0.350 | 54 | 108 |
