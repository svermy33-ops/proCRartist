// Import this folder into Unity Assets. Built-in Standard / URP Lit.
// All changes are scoped to Assets/BREAK_NORTH_M6_Architecture.
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using UnityEditor;
using UnityEditor.SceneManagement;

namespace BreakNorth.Architecture675.Editor
{
    [Serializable] public sealed class Kit { public string version; public Asset[] assets; public Layout[] scenes; }
    [Serializable] public sealed class Asset {
        public string key, category, pivot; public bool fixture;
        public float[] dimensions, boundsMin, boundsMax;
        public string[] materialNames, roles, families; public Box[] colliders;
    }
    [Serializable] public sealed class Box { public float[] center, size; }
    [Serializable] public sealed class Layout { public string name; public Placement[] placements; }
    [Serializable] public sealed class Placement { public string key; public float[] position; public float rotationZ; }

    public sealed class ImportSettings : AssetPostprocessor
    {
        void OnPreprocessTexture()
        {
            if (!assetPath.StartsWith(Builder.Root + "/Textures/", StringComparison.Ordinal)) return;
            var t=(TextureImporter)assetImporter;
            bool normal=assetPath.EndsWith("_Normal.png",StringComparison.Ordinal);
            bool packed=assetPath.EndsWith("_MetallicSmoothness.png",StringComparison.Ordinal);
            t.textureType=normal?TextureImporterType.NormalMap:TextureImporterType.Default;
            t.sRGBTexture=!normal&&!packed;
            t.convertToNormalmap=false;
            t.alphaSource=TextureImporterAlphaSource.FromInput;
            t.alphaIsTransparency=false; t.mipmapEnabled=true;
            t.wrapMode=TextureWrapMode.Repeat; t.filterMode=FilterMode.Trilinear;
            t.anisoLevel=4; t.maxTextureSize=1024;
            t.textureCompression=TextureImporterCompression.CompressedHQ;
        }
        void OnPreprocessModel()
        {
            if (!assetPath.StartsWith(Builder.Root + "/Models/", StringComparison.Ordinal)) return;
            var m=(ModelImporter)assetImporter;
            m.globalScale=1; m.useFileScale=true;
            m.importNormals=ModelImporterNormals.Import;
            m.importTangents=ModelImporterTangents.CalculateMikk;
            m.generateSecondaryUV=false; m.addCollider=false;
            m.importAnimation=false; m.isReadable=false;
        }
    }

    public static class Builder
    {
        public const string Root="Assets/BREAK_NORTH_M6_Architecture";
        static Kit ReadKit() { return JsonUtility.FromJson<Kit>(File.ReadAllText(Root+"/KitManifest.json")); }
        static Vector3 Position(float[] p) { return new Vector3(p[0],p[2],-p[1]); }
        static Vector3 Size(float[] p) { return new Vector3(p[0],p[2],p[1]); }
        static void Folder(string path) {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent=Path.GetDirectoryName(path).Replace('\\','/'); Folder(parent);
            AssetDatabase.CreateFolder(parent,Path.GetFileName(path));
        }
        static Shader GetShader() {
            if (GraphicsSettings.currentRenderPipeline==null) return Shader.Find("Standard");
            if (GraphicsSettings.currentRenderPipeline.GetType().Name.Contains("Universal")) return Shader.Find("Universal Render Pipeline/Lit");
            throw new InvalidOperationException("BN675 supports Built-in Standard or URP Lit. HDRP needs explicit material conversion.");
        }
        static Texture2D Texture(string family,string map) {
            var t=AssetDatabase.LoadAssetAtPath<Texture2D>(Root+"/Textures/"+family+"_"+map+".png");
            if (t==null) throw new FileNotFoundException(family+"_"+map); return t;
        }
        static Color DefaultTint(string family) {
            string hex="#FFFFFF";
            switch(family) {
                case "ConcreteSurfaceNeutral": hex="#E4D9C3"; break;
                case "ConcreteInterior": hex="#C5BBA5"; break;
                case "PaintedMetalNeutral": hex="#B5C8D8"; break;
                case "BareCutMetal": hex="#CBD4DC"; break;
                case "StructuralSteel": hex="#AABECE"; break;
                case "FloorNeutral": hex="#C6C9C5"; break;
                case "CeilingNeutral": hex="#EBE5D6"; break;
                case "ReinforcedInterior": hex="#B8B3A5"; break;
            }
            ColorUtility.TryParseHtmlString(hex,out var color); return color;
        }
        static Material MakeMaterial(string name,string family,Shader shader) {
            string path=Root+"/Materials/"+name+".mat";
            var m=AssetDatabase.LoadAssetAtPath<Material>(path);
            bool create=m==null; if(create)m=new Material(shader); else m.shader=shader;
            m.name=name;
            bool urp=shader.name.StartsWith("Universal",StringComparison.Ordinal);
            m.SetTexture(urp?"_BaseMap":"_MainTex",Texture(family,"BaseColor"));
            // v2 handoff palette; Build reapplies defaults. Face A/B remain independent.
            m.SetColor(urp?"_BaseColor":"_Color",DefaultTint(family));
            m.SetTexture("_BumpMap",Texture(family,"Normal"));m.SetFloat("_BumpScale",1);
            m.SetTexture("_MetallicGlossMap",Texture(family,"MetallicSmoothness"));
            m.SetFloat("_Metallic",1);
            if(m.HasProperty("_Smoothness"))m.SetFloat("_Smoothness",1);
            if(m.HasProperty("_GlossMapScale"))m.SetFloat("_GlossMapScale",1);
            if(m.HasProperty("_Glossiness"))m.SetFloat("_Glossiness",1);
            if(m.HasProperty("_SmoothnessTextureChannel"))m.SetFloat("_SmoothnessTextureChannel",0);
            m.EnableKeyword("_NORMALMAP");
            m.EnableKeyword(urp?"_METALLICSPECGLOSSMAP":"_METALLICGLOSSMAP");
            m.DisableKeyword("_SMOOTHNESS_TEXTURE_ALBEDO_CHANNEL_A");
            if(create)AssetDatabase.CreateAsset(m,path);else EditorUtility.SetDirty(m);
            return m;
        }

        [MenuItem("BREAK NORTH/M6 Architecture/1 - Build Materials and Prefabs")]
        public static void Build()
        {
            var kit=ReadKit(); var shader=GetShader();
            if(shader==null)throw new InvalidOperationException("Required Lit shader is unavailable.");
            Folder(Root+"/Materials");Folder(Root+"/Prefabs");
            var materials=new Dictionary<string,Material>();
            foreach(var a in kit.assets)
                for(int i=0;i<a.materialNames.Length;i++)
                    materials[a.materialNames[i]]=MakeMaterial(a.materialNames[i],a.families[i],shader);
            AssetDatabase.SaveAssets();
            foreach(var a in kit.assets)
            {
                string modelPath=Root+"/Models/SM_BN675_"+a.key+".fbx";
                var importer=(ModelImporter)AssetImporter.GetAtPath(modelPath);
                if(importer==null)throw new FileNotFoundException(modelPath);
                for(int i=0;i<a.materialNames.Length;i++)
                    importer.AddRemap(new AssetImporter.SourceAssetIdentifier(typeof(Material),a.materialNames[i]),materials[a.materialNames[i]]);
                importer.SaveAndReimport();
                var model=AssetDatabase.LoadAssetAtPath<GameObject>(modelPath);
                var root=new GameObject(a.key);
                try {
                    var visual=(GameObject)PrefabUtility.InstantiatePrefab(model);
                    visual.name="Visual";visual.transform.SetParent(root.transform,false);
                    // Imported node transforms are retained. Colliders are in the root metre coordinate system.
                    foreach(var renderer in visual.GetComponentsInChildren<Renderer>(true)) {
                        var shared=renderer.sharedMaterials;
                        for(int i=0;i<shared.Length;i++) {
                            string name=shared[i]!=null?shared[i].name:"";
                            if(materials.TryGetValue(name,out var replacement)) shared[i]=replacement;
                        }
                        renderer.sharedMaterials=shared;
                    }
                    var collision=new GameObject("Collision_CompoundBoxes");collision.transform.SetParent(root.transform,false);
                    for(int i=0;i<a.colliders.Length;i++) {
                        var box=collision.AddComponent<BoxCollider>();box.center=Position(a.colliders[i].center);box.size=Size(a.colliders[i].size);
                    }
                    PrefabUtility.SaveAsPrefabAsset(root,Root+"/Prefabs/"+a.key+".prefab");
                } finally { UnityEngine.Object.DestroyImmediate(root); }
            }
            AssetDatabase.SaveAssets();
            Debug.Log("BN675: built "+kit.assets.Length+" prefabs. Run validation, then create the reference scene. Runtime destruction/networking is not included.");
        }

        [MenuItem("BREAK NORTH/M6 Architecture/2 - Validate Imported Prefabs")]
        public static void Validate()
        {
            int checkedAssets=0;var failures=new List<string>();
            foreach(var a in ReadKit().assets) {
                var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(Root+"/Prefabs/"+a.key+".prefab");
                if(prefab==null){failures.Add(a.key+": missing prefab");continue;}
                var instance=(GameObject)PrefabUtility.InstantiatePrefab(prefab);
                try {
                    var renderers=instance.GetComponentsInChildren<Renderer>();
                    if(renderers.Length==0){failures.Add(a.key+": no renderer");continue;}
                    var bounds=renderers[0].bounds;foreach(var r in renderers.Skip(1))bounds.Encapsulate(r.bounds);
                    Vector3 expected=Size(a.dimensions);
                    if((bounds.size-expected).magnitude>.002f)failures.Add(a.key+": dimensions "+bounds.size+", expected "+expected);
                    Vector3 expectedCenter=(Position(a.boundsMin)+Position(a.boundsMax))*.5f;
                    if((bounds.center-expectedCenter).magnitude>.002f)failures.Add(a.key+": pivot / orientation mismatch");
                    foreach(var r in renderers)
                        if(r.sharedMaterials.Any(m=>m==null||!m.HasProperty("_BumpMap")||m.GetTexture("_BumpMap")==null))failures.Add(a.key+": missing PBR material");
                    if(instance.GetComponentsInChildren<BoxCollider>().Length!=a.colliders.Length)failures.Add(a.key+": collider count mismatch");
                    if(instance.transform.localScale!=Vector3.one)failures.Add(a.key+": root scale is not one");
                    checkedAssets++;
                } finally { UnityEngine.Object.DestroyImmediate(instance); }
            }
            Folder(Root+"/Validation");
            string report="Unity "+Application.unityVersion+"\nChecked "+checkedAssets+" assets\n"+(failures.Count==0?"PASS: dimensions, pivots, material presence, root scale, collider count.\n":"FAIL:\n"+string.Join("\n",failures));
            report+="\nNot covered: gameplay destruction, physics behavior, lighting bake, rendering quality, save/load/late join.";
            File.WriteAllText(Root+"/Validation/UnityImportReport.txt",report);AssetDatabase.Refresh();
            if(failures.Count>0)throw new InvalidOperationException(report);Debug.Log(report);
        }

        [MenuItem("BREAK NORTH/M6 Architecture/3 - Create Assembly and Cut Reference Scene")]
        public static void CreateReferenceScene()
        {
            var kit=ReadKit();
            foreach(var a in kit.assets)
                if(AssetDatabase.LoadAssetAtPath<GameObject>(Root+"/Prefabs/"+a.key+".prefab")==null)
                    throw new InvalidOperationException("Run Build Materials and Prefabs first.");
            Folder(Root+"/Scenes");
            // A new unique additive scene preserves the user's currently open scene and prior references.
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);
            SceneManager.SetActiveScene(scene);
            for(int index=0;index<kit.scenes.Length;index++) {
                var layout=kit.scenes[index];var group=new GameObject(layout.name);
                SceneManager.MoveGameObjectToScene(group,scene);
                group.transform.position=new Vector3((index%4)*16,0,(index/4)*16);
                foreach(var p in layout.placements) {
                    var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(Root+"/Prefabs/"+p.key+".prefab");
                    var instance=(GameObject)PrefabUtility.InstantiatePrefab(prefab,scene);
                    instance.transform.SetParent(group.transform,false);
                    instance.transform.localPosition=Position(p.position);
                    instance.transform.localRotation=Quaternion.Euler(0,p.rotationZ,0);
                }
            }
            var lightObject=new GameObject("Reference Directional Light");SceneManager.MoveGameObjectToScene(lightObject,scene);
            var light=lightObject.AddComponent<Light>();light.type=LightType.Directional;light.intensity=1.25f;lightObject.transform.rotation=Quaternion.Euler(45,-35,0);
            string path=AssetDatabase.GenerateUniqueAssetPath(Root+"/Scenes/BN675_Assembly_And_Cut_References.unity");
            EditorSceneManager.SaveScene(scene,path);
            Debug.Log("Created "+path+". Cut scenes are static geometric references; run the project's destruction/save/load/late-join tests separately.");
        }
    }
}
